title: Tomcat部署多个war包项目，以及jar包项目的部署
date: '2019-09-20 16:33:38'
updated: '2019-10-02 08:54:37'
tags: [Tomcat]
permalink: /articles/2019/09/20/1568968418136.html
---
![](https://img.hacpai.com/bing/20190814.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 1、war 包和 jar 包

  JavaSE 程序可以打包成 jar 包，而 JavaWeb 程序可以打包成 war 包。然后把 war 发布到 Tomcat 的 webapps 目录下，Tomcat 会在启动时自动解压 war 包。jar 是与平台无关的文件格式，它允许将许多文件组合成一个压缩文件。

#### 1）jar 包

  JAR 文件格式以流行的 ZIP 文件格式为基础。与 ZIP 文件不同的是，JAR 文件不仅用于压缩和发布，而且还用于部署和封装库、组件和插件程序，并可被像编译器和 JVM 这样的工具直接使用。
  打成 jar 包的项目直接通过内置 Tomcat 运行，不需要额外安装 Tomcat。如需修改内置 tomcat 的配置，需要修改配置文件，内置 tomcat 没有自己的日志输出，全靠 jar 包应用输出日志。但是比较方便，快速，比较简单

#### 2）war 包

  war 包项目的部署，需要安装 Tomcat，然后放到 waeapps 目录下运行 war 包。可以灵活选择 tomcat 版本，可以直接修改 tomcat 的配置，有自己的 tomcat 日志输出，可以灵活配置安全策略，相对打成 jar 包来说没那么快速方便。

#### 3）jar 包和 war 包部署项目的区别

  jar 包运行项目是通过内置 Tomcat 运行，每个 jar 包项目是相互独立的，部署几个 jar 包项目电脑上就运行几个 Tomcat。而 war 项目运行多个项目部署到一个 Tomcat 上，可以节约内存。
  个人比较倾向于 war 包，因为我的云服务器内存并不大，如果所有项目 Jar 包的话，每个项目都启动一个 Tomcat 会占用大量内存。

### 2、使用 Maven 打 Jar 包和 War 包

#### 1）选择包
&emsp;&emsp;这里决定生成什么包
![image.png](https://img.hacpai.com/file/2019/09/image-72039415.png)

#### 2）清除 target 文件
&emsp;&emsp;执行 clean 命令清除 target 文件
![image.png](https://img.hacpai.com/file/2019/09/image-974fd12b.png)

  控制台打印以下信息表示成功

```
[INFO] --- maven-clean-plugin:3.1.0:clean (default-clean) @ forum ---
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
```

#### 3）打包
&emsp;&emsp;接着执行 package 进行打包

![image.png](https://img.hacpai.com/file/2019/09/image-1cc92f84.png)
  控制台打印以下信息表示成功

```
[INFO] Replacing main artifact with repackaged archive
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
```

#### 4）生成路径
&emsp;&emsp;包所在路径
![image.png](https://img.hacpai.com/file/2019/09/image-4c449fbc.png)`

### 3、war 包项目的部署

  war 项目运行在 Tomcat 中，所以电脑上要有 Tomcat。

#### 1）修改配置文件

  打开 server.xml 文件，删除默认的 Service ，写入以下信息（一个项目一个 Service）。

```
# name项目名（其他属性根据需要进行设置）
<Service name="项目名">
	# port端口号
	<Connector port="10014" protocol="HTTP/1.1" maxThreads="700" acceptCount="100" connectionTimeout="2000" redirectPort="8445" URIEncoding="UTF-8"/>
	# name项目名	
	<Engine name="项目名" defaultHost="localhost">
		# appBase项目所在文件夹名
		<Host name="localhost" appBase="webapps">
			# docBase项目所在路径
			<Context docBase="G:\javaTools\apache-tomcat-8.0.48\webapps\项目名" path="" reloadable="true" />
			<Valve className="org.apache.catalina.valves.AccessLogValve" directory="logs" prefix="localhost_access_log" suffix=".txt" pattern="%h %l %u %t &quot;%r&quot; %s %b" />
		</Host>
	</Engine>
</Service>
```

#### 2）放置 war 包

  将 war 放到配置文件中对应的目录中。
![image.png](https://img.hacpai.com/file/2019/09/image-17023f2e.png)

#### 3）运行项目

  运行 Tomcat，运行的日志信息是根据配置文件的路径进行输出。

### 4、jar 包项目的部署

  在 jar 包项目所在目录执行命令（forum.jar是jar包名）。
方法一：直接运行 jar 包

```
java -jar forum.jar
```

方法二：后台运行 jar 包（日志默认输出到当前目录中）

```
nohup java -jar forum.jar &
```

