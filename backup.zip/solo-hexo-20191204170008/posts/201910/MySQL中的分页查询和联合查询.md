title: MySQL中的分页查询和联合查询
date: '2019-10-15 17:13:37'
updated: '2019-10-15 17:13:37'
tags: [MySQL]
permalink: /articles/2019/10/15/1571130817223.html
---
![](https://img.hacpai.com/bing/20190604.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 一、分页查询  
  当要显示的数据，一页显示不完，需要分页提交sql请求，获取不同的数据库时使用分页查询。  
#### 1、语法：  
  offset表示要显示条目的起始索引（索引从0开始），公式：起始索引=（要显示的页数-1）*size。  
  size表示要显示的数据个数。  
~~~  
select 查询列表   
form 表名  
[where 筛选条件]   
[group  by 分组列表 [having 分组条件] ]   
[order  by 排序列表 [asc|desc] ]   
[limit offset,size];  
~~~  
  
#### 2、例子：  
~~~  
select *   
from curriculum   
limit 0,3;  
~~~  
### 二、联合查询  
  
  联合查询可以将多条查询语句的结果合并成一个结果。当要查询的结果来之多个表，且多个表没有直接的连接关系，但是查询的信息一致时可以使用联合查询。  
  
#### 1、特点：  
  
  ①要求多条查询语句的查询列数是一致的。  
  ②要求多条查询语句的查询的每一列的类型和顺序最好一致。  
  ③union 关键字默认去重，如果使用 union all 可以包含重复项。  
  
#### 2、语法：  
  
```  
查询语句1  
union  
查询语句2  
union  
...  
```  
  
#### 3、例子  
  
```  
select id,name,class  
from student  
union  
select id,student_id,curriculum_name  
from curriculum;  
```
