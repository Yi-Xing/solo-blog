title: Linux（Centos7.6）中Redis的下载，启动，关闭，修改密码，外网访问
date: '2019-09-18 15:21:18'
updated: '2019-09-20 10:09:53'
tags: [Redis, Linux]
permalink: /articles/2019/09/18/1568791278084.html
---
![](https://img.hacpai.com/bing/20180808.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 1、下载

[Redis官网下载](https://redis.io/download)


#### 1）下载压缩包
```
wget http://download.redis.io/releases/redis-5.0.5.tar.gz
```
#### 2）解压
```
tar xzf redis-5.0.5.tar.gz
```
#### 3）切换到Redis文件中
```
cd redis-5.0.5
```
#### 4）安装Redis
```
make
```

### 2、启动

#### 1）直接启动
切换到src下执行
```
./redis-server ../redis.conf
```

显示该页面表示运行成功，想要退出按 Ctrl+C
![image.png](https://img.hacpai.com/file/2019/09/image-5dc0488e.png)

#### 2）后台启动
找到 Redis 的配置文件 redis.conf 将其第 137 行左右(我的是 137 行)的 daemonize 后面的值修改为 yes。
![image.png](https://img.hacpai.com/file/2019/09/image-e76d5ea4.png)
大概意思默认情况下不作为守护进程运行。如果你需要使用“是”。
然后切换到src下执行
```
./redis-server ../redis.conf
```

显示以下信息表示成功

![image.png](https://img.hacpai.com/file/2019/09/image-54e51ffe.png)

### 3、外网访问

#### 1）打开端口
&emsp;&emsp;首先确保防火墙端口打开(如果是阿里云服务器，还需在阿里云控制台将端口打开)Redis 默认端口为 3679。
#### 2)修改配置文件
&emsp;&emsp;打开 Redis 的配置文件 redis.conf 将其第 69 行左右(我的是 69 行)的 bind 注掉即可。
![image.png](https://img.hacpai.com/file/2019/09/image-4afd6232.png)
#### 3)重新启动即可


### 4、关于密码
&emsp;&emsp;Redis的密码存储在配置文件中，打开redis.conf文件，将其第 510 行左右(我的是 510 行)的 requirepass 后面的值为密码。
![image.png](https://img.hacpai.com/file/2019/09/image-8599e6c3.png)

#### 1）进入Redis的命令窗口
在src目录下执行，想要退出按 Ctrl+C
```
./redis-cli
```
#### 2）输入密码进行授权
```
auth 密码
```
#### 3）修改密码
&emsp;&emsp;使用该命令修改密码只是临时的，并没有修改配置文件，重启后又恢复成原密码，可以通过修改配置文件修改密码。
```
config set requirepass 密码
```

### 5、关闭
#### 1）查找Redis的进程信息
```
netstat -lnp|grep redis 
如：tcp        0      0 0.0.0.0:6379            0.0.0.0:*               LISTEN      12748/./redis-serve 
```
#### 2）然后关闭该进程
```
kill -9 12748
```

