title: Java中泛型的应用
date: '2019-10-24 10:08:47'
updated: '2019-10-24 11:13:39'
tags: [JavaSE]
permalink: /articles/2019/10/24/1571882926981.html
---
![](https://img.hacpai.com/bing/20190117.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 一、泛型的引入原因

  在开发中往往会出现一下代码：

```
public class Demo {
    public static void main(String[] args) {
        List list=new ArrayList();
        list.add("zyxwmj.top");
	//list.add(new Demo());
        String str=null;
        for(Object s:list){
            str=(String) s;
        }
        System.out.println(str);
    }
}
```

  在上面代码集合的存储类型是 Object 类型，向集合中添加对象时，都是自动向上转型，可以加入任何类型的元素。但是，在取出元素的时候，通常需要向下转型，此时就可能出现类型转换异常。
  在 JDK1.5 时候提出一个解决方案：泛型，暂时先不追究它内在是怎么实现的，只要知道使用泛型定义集合，我们就不需要强制类型转换，可以避免一些安全隐患。

### 二、泛型的定义

  泛型的定义格式是用尖括号括起来的类型参数实现的，一般用 T 或 E 这样的单个大写字母来表示类型参数。当一个泛型有多个类型参数时，每个类型参数在该泛型中都应该是唯一的。如果不能定义为Zyx(T,T)形式的泛型，但可以定义为Zyx(T,E)形式的泛型
注意：泛型只能使用引用类型，不能使用基本类型。

#### 1、泛型类或接口

  泛型类或接口：表示该类或接口以后要操作的引用类型不确定，所以在定义的时候需要定义为泛型类或接口，在创建对象的时候，指定具体要操作的类型。

##### 泛型类的定义

```
[修饰符] class 类名<T>
```

##### 泛型接口的定义

```
[修饰符] interface 接口名<T>
```
##### 泛型类的使用
```
public class Zyx<T> {
    private  T a;
    public T getA() {
        return a;
    }
    public void setA(T a) {
        this.a = a;
    }

    public static void main(String[] args) {
        Zyx<String> name=new Zyx<String>();
        Zyx<Integer> age=new Zyx<Integer>();
        name.setA("zyxwmj.top");
        age.setA(18);
        System.out.println(name.getA());
        System.out.println(age.getA());
    }
}
```
#### 2、泛型方法
  表示该方法以后要操作的引用类型不确定，所以在定义的时候定义为泛型方法。定义与其所在的类或接口是否为泛型类或接口没有关系。要定义泛型方法，只需要将泛型的类型参数<T>置于方法返回值类型前即可。泛型方法除了定义不同，调用时与普通方法一样。静态方法，无法访问泛型类的类型参数，如果静态方法需要使用泛型能力，必须将其定义为泛型方法。

##### 泛型方法的定义

```
[修饰符] <T> 返回值类型 方法名(T 参数,参数列表)  
```
##### 泛型方法的应用  
```
public class Zyx{
    public static <T> void zyx(T a){
        System.out.println(a.getClass());
        System.out.println(a);
    }

    public static void main(String[] args) {
        Zyx.zyx("zyxwmj.top");
        Zyx.zyx(2);
    }
}
```
### 三、泛型的高级应用

　　1.泛型通配符：？表示，通常用于操作任意参数类型的泛型。

　　2.泛型的界限：其目的是在一定范围内扩大可以操作的参数类型。分为上界限，和下界限。
　　泛型上界：表现形式：&lt;? extends A&gt; 表示的含义是：可以操作的参数类型可以是，A 类型以及 A 的子类。通常这种在集合中取出元素的时候常常使用，通常用 A 类型来接收取出的元素。
　　泛型下界：表现形式：&lt;? super A&gt; 表示的含义是：可以操作的参数类型是：A 类型及其父类型，泛型下限的使用不多。



