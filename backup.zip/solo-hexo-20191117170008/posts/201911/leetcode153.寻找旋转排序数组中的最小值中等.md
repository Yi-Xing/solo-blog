title: leetcode——153. 寻找旋转排序数组中的最小值（中等）
date: '2019-11-16 17:40:17'
updated: '2019-11-17 08:10:45'
tags: [leetcode]
permalink: /articles/2019/11/16/1573897217279.html
---
### 1、题目

  假设按照升序排序的数组在预先未知的某个点上进行了旋转。( 例如，数组 [0,1,2,4,5,6,7] 可能变为 [4,5,6,7,0,1,2] )。请找出其中最小的元素。你可以假设数组中不存在重复元素。[leetcode链接](https://leetcode-cn.com/problems/find-minimum-in-)

### 2、例子

#### 示例 1:

  输入: [3,4,5,1,2]
  输出: 1

#### 示例 2:

  输入: [4,5,6,7,0,1,2]
  输出: 0

### 3、思路

  假如有一个数组为{1,2,3,4,5}，它可以被旋转为：

```java
1 2 3 4 5
2 3 4 5 1
3 4 5 1 2
4 5 1 2 3
5 1 2 3 4
```

#### 方法一：

 **我们可以找到一个变化点，这个点有如下特点：**

* 所有变化点左侧元素 &gt; 数组第一个元素
* 所有变化点右侧元素 &lt; 数组第一个元素

 **判断变化点的位置：**

* 找到数组的中间元素 mid。
* 如果中间元素 &gt; 数组第一个元素，则变化点在 mid 右边。
* 如果中间元素 &lt; 数组第一个元素，则变化点在 mid 左边。

 **验证是否找到变化点：**

* 当我们找到变化点时停止搜索，当以下条件满足任意一个即可：
* nums[mid] &gt; nums[mid + 1]，因此 mid+1 是最小值。
* nums[mid - 1] &gt; nums[mid]，因此 mid 是最小值。

#### 方法二：

  我们把数组从中间分成两个数组（两个数组都含中间数），不难发现最小数永远在无序数组中。

 **解决办法：**

* 如果中间的数小于等于右边的数，表示右边的数是有序的，则说明最小数的下标为 &lt;= mid
* 如果中间的数大于右边的数，表示左边的数是有序的，则说明最小数的下标为 &gt; mid

### 四、Java 代码实现

#### 方法一：

```java
    public int findMin(int[] nums) {
        if (nums.length == 1) {
            return nums[0];
        }
        int left = 0;
        int right = nums.length - 1;
        if (nums[0] < nums[right]) {
            return nums[0];
        }
        while (true) {
            int mid = (left + right) / 2;
            if (nums[mid] > nums[mid + 1]) {
                return nums[mid + 1];
            }
            if (nums[mid] < nums[mid - 1]) {
                return nums[mid];
            }
            if (nums[mid] > nums[0]) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
    }
```

#### 方法二：

```java
    public int findMin(int[] nums) {
        int left = 0, right = nums.length - 1;
        while (left < right) {
            int mid = (right + left) / 2;
            if (nums[mid] <= nums[right]) {
                right = mid;
            } else {
                left = mid + 1;
            }
        }
        return nums[left];
    }
```
### 4、运行效率
#### 方法一：
![image.png](https://img.hacpai.com/file/2019/11/image-f4a2c449.png)

#### 方法二：
![image.png](https://img.hacpai.com/file/2019/11/image-9a1ddaef.png)

