title: MySQL中的函数
date: '2019-10-07 22:41:34'
updated: '2019-10-08 15:17:43'
tags: [MySQL]
permalink: /articles/2019/10/07/1570459294550.html
---
![](https://img.hacpai.com/bing/20190821.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、字符函数
#### 1、length 获取参数值的长度

```
select length(23); 
```

#### 2、lower 将字母变成小写

```
select lower ('A'); 
```

#### 3、upper 将字母变成大写

```
select upper ('a'); 
```

#### 4、concat 拼接字符串

```
select concat ('a','b','cd'); 
```

#### 5、substr 和 substring 字符串截取
  两个函数作用一样，从第 3 个字符开始截取，运行结果：zyxwmj.top

```
select substr('网站zyxwmj.top',3); 
```

  从第 2 个字符开始截取 4 个字符，运行结果站：zyx

```
select substr('网站zyxwmj.top',2,4); 
```

#### 6、instr 查找字符
  返回子串第一次出现的索引，如果找不到返回 0。

```
select instr('网站zyxwmj.top','zyx'); 
```

#### 8、trim 舍去指定字符
  默认去掉字符前面和后面的所有空格。

```
select trim('   zyxwmj.top   '); 
```

  去掉字符前面和后面的所有 6。

```
select trim('6' from '666zyxwmj.top666'); 
```

#### 9、lpad 用指定字符从左填充指定长度
  运行结果为：66hi

```
select lpad('hi',4,'6') ;
```

#### 10、rpad 用指定字符从右填充指定长度

  运行结果为：hi66

```
select rpad ('hi',4,'6') ;
```

#### 11、replace 替换指定字符

```
select replace ('zyxwmj.top','wmj','zyx') ;
```

### 二、数学函数
#### 1、round 四舍五入

```
select round (5.5);
```

#### 2、ceil 向上取整，返回 &gt;= 该参数的最小整数

```
select ceil  (5.4);
```

#### 3、floor 向下取整，返回 &lt;= 该整数的最大整数

```
select floor (6.9);
```

#### 4、truncate 保留几位小数，直接舍去

```
select truncate (6.699999,1);
```

#### 5、mod 取余，相当于%

```
select mod (10,3);
```

### 三、日期函数
#### 1、now 返回当前系统的日期时间

```
select now();
```

#### 2、curdate 返回当前系统日期，不包含时间

```
select curdate();
```

#### 3、curtime 返回当前时间，不包含日期

```
select curtime();
```

#### 4、year 获取时间中的年

```
select year('2000-10-30');
```

#### 5、month 获取时间中的月

```
select month('2000-10-30');
```

#### 6、str_to_date 将日期格式的字符转成指定格式的日期

```
select str_to_date('30-10-2000','%d-%m-%Y');
```

#### 7、date_format 将日期转成字符

```
select date_format('2000-10-30','%Y年%m月%d日');
```

|格式符|功能|
|---|---|
|%Y|四位的年份|
|%y|两位数的年份|
|%m|月份(01,02....11,12)|
|%c|月份(1,2....11,12)|
|%d|日(01,02....)|
|%H|小时(24 小时制)|
|%h|小时(12 小时制)|
|%i|分钟(00,01....58,59)|
|%s|秒(00,01....58,59)|

### 四、其他函数
#### 1、version 查看 MySQL 版本

```
select version();
```

#### 2、database 查看当前所在数据库

```
select database();
```

#### 3、user 查看当前登录的用户

```
select user();
```

### 五、流程控制函数
#### 1、if 函数
  类似于 Java 等编程语言的三元运算符。

```
select if(10<5,'对','错');
```

#### 2、case 函数
  1）语法

```
case 要判断的字段或表达式
when 常量1 then 要显示的值1或语句1
when 常量2 then 要显示的值2或语句2
...
else 要显示的值n或语句n
end
```

  2）例子

```
select id,case name
	when 'zyx1' then '我是zyx1'
	when 'zyx2' then '我是zyx2'
	else '我不是zyx'
	end
from user
```

### 六、分组函数
  分组函数又称聚合函数、统计函数、组函数。
#### 特点：
  1）sum、avg 一般用于处理数值型，max、min、count 可处理任意类型。
  2）分组函数都忽略 null 值。
  3）可以和 distinct 搭配实现去重运算。
  4）count 函数一般使用 * 统计行数。
  效率：
    MYISAM 存储引擎下，count(*) 的效率最高。
    INNODB 存储引擎下，count(*) 和 count(1)的效率差不多，比 count(字段)效率高。

#### 1、sum 求和

```
select sum(age) from user;
```

#### 2、avg 平均值

```
select avg(age) from user;
```

#### 3、max 最大值

```
select max(age) from user;
```

#### 4、min 最小值

```
select min(age) from user;
```

#### 5、count 统计个数

```
select count(*) from user;
```

