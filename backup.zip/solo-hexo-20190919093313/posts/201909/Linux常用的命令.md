title: Linux常用的命令
date: '2019-09-16 22:04:33'
updated: '2019-09-18 15:24:48'
tags: [Linux]
permalink: /articles/2019/09/16/1568642673331.html
---
![](https://img.hacpai.com/bing/20190512.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 1、路径

1）切换到其他目录

```
cd 目录路径  
```

2）返回父级目录

```
cd ..
```

3）查看当前路径

```
pwd  
```

4）查看当前目录的文件（不含隐藏文件）

```
ls
```

### 2、文件

1）全盘查找指定文件 （可使用通配符）

```
sudo find / -name *Java*
```

2）创建文件夹

```
mkdir 文件夹名
```

3）编辑文件（文件不存在直接创建）

```
vi 文件路径
```

4）移动文件

```
mv 原文件或目录 目标文件或目录  
```

5）复制文件

```
cp 原文件或目录 目标文件或目录
```

6）删除文件

```
rm -rf 文件路径
```

7）下载文件

```
wget 下载路径
```

8）解压文件（解压到当前路径）

```
tar -zxvf 压缩包路径
```

### 3、防火墙和端口

1）检查防火墙状态

```
systemctl status firewalld
```

2）启动防火墙

```
systemctl start firewalld
```
3）重启firewall
```
firewall-cmd --reload
```

4）开机启用防火墙

```
systemctl enable firewalld.service  
```

5）开机禁用防火墙

```
systemctl disable firewalld.service
```

6）查看已经开放的端口：

```
firewall-cmd --list-ports  
```

7）开启端口（阿里云还需要在服务器控制台开启端口）开启端口后必须重启防火墙才会生效

```
firewall-cmd --zone=public --add-port=80/tcp --permanent  
命令含义：
–zone #作用域
–add-port=80/tcp #添加端口，格式为：端口/通讯协议
–permanent #永久生效，没有此参数重启后失效
```

8）关闭防火墙端口

```
firewall-cmd --zone=public --remove-port=80/tcp --permanent
```

9）检查端口被哪个进程占用

```
netstat -lnp|grep 端口号或应用名
```

10）查看进程的详细信息

```
ps ID
```

11）关闭进程

```
kill -9 ID
```

