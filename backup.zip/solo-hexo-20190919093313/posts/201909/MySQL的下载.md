title: MySQL的下载
date: '2019-09-16 14:48:00'
updated: '2019-09-16 21:10:43'
tags: [MySQL]
permalink: /articles/2019/09/16/1568616480019.html
---
![](https://img.hacpai.com/bing/20190724.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### MySQL 的下载

[MySQL下载官网](https://dev.mysql.com/downloads/mysql/)
![image.png](https://img.hacpai.com/file/2019/09/image-cafe3ed8.png)

下载完毕后解压

### 配置环境变量 或 切换到MySQL的bin目录
以管理员身份运行DOS命令框执行以下命令
```
# 初始化数据目录 使用 了--initialize“ 默认安全 ”安装（即包括生成随机初始的 `root`密码） 使用该--console选项将消息定向到控制台
# 控制台会打印出默认密码
mysqld --initialize --console

# 安装
mysqld  --install

#启动数据库
net start mysql

# 启动后，输入以下命令，然后按回车输入默认密码
mysql -u root -p

# 进入MySQL后修改密码
ALTER  USER  'root'@'localhost'  IDENTIFIED  BY  '新密码';
```

