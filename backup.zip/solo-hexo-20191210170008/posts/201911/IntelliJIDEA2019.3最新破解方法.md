title: IntelliJ IDEA2019.3 最新破解方法
date: '2019-11-29 21:40:46'
updated: '2019-12-06 09:47:36'
tags: [其他]
permalink: /articles/2019/11/29/1575034846254.html
---
![](https://img.hacpai.com/bing/20171104.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

#### 此文章仅用于学习研究使用，如有侵权，请联系我删除该文章！！！

### 一、下载

  进入官网，选择适合自己系统的版本进行下载，下载地址：[https://www.jetbrains.com/idea/download/#section=windows](https://www.jetbrains.com/idea/download/#section=windows)

![image.png](https://img.hacpai.com/file/2019/11/image-1ddbe544.png)

  安装就不多解释了，一直 next 即可。

### 二、破解

#### 有能力的朋友尽量支持正版！

  启动 idea 后提示需要激活的窗口，选中 Activation code，然后将激活码粘入，点击 Activate（激活）即可。目前的**有效时间到 2020 年 9 月 2 号**。

![image.png](https://img.hacpai.com/file/2019/11/image-a40c2213.png)

**激活码：**

```java
6ZUMD7WWWU-eyJsaWNlbnNlSWQiOiI2WlVNRDdXV1dVIiwibGljZW5zZWVOYW1lIjoiSmV0cyBHcm91cCIsImFzc2lnbmVlTmFtZSI6IiIsImFzc2lnbmVlRW1haWwiOiIiLCJsaWNlbnNlUmVzdHJpY3Rpb24iOiIiLCJjaGVja0NvbmN1cnJlbnRVc2UiOmZhbHNlLCJwcm9kdWN0cyI6W3siY29kZSI6IklJIiwiZmFsbGJhY2tEYXRlIjoiMjAxOS0wOS0wMyIsInBhaWRVcFRvIjoiMjAyMC0wOS0wMiJ9LHsiY29kZSI6IkFDIiwiZmFsbGJhY2tEYXRlIjoiMjAxOS0wOS0wMyIsInBhaWRVcFRvIjoiMjAyMC0wOS0wMiJ9LHsiY29kZSI6IkRQTiIsImZhbGxiYWNrRGF0ZSI6IjIwMTktMDktMDMiLCJwYWlkVXBUbyI6IjIwMjAtMDktMDIifSx7ImNvZGUiOiJQUyIsImZhbGxiYWNrRGF0ZSI6IjIwMTktMDktMDMiLCJwYWlkVXBUbyI6IjIwMjAtMDktMDIifSx7ImNvZGUiOiJHTyIsImZhbGxiYWNrRGF0ZSI6IjIwMTktMDktMDMiLCJwYWlkVXBUbyI6IjIwMjAtMDktMDIifSx7ImNvZGUiOiJETSIsImZhbGxiYWNrRGF0ZSI6IjIwMTktMDktMDMiLCJwYWlkVXBUbyI6IjIwMjAtMDktMDIifSx7ImNvZGUiOiJDTCIsImZhbGxiYWNrRGF0ZSI6IjIwMTktMDktMDMiLCJwYWlkVXBUbyI6IjIwMjAtMDktMDIifSx7ImNvZGUiOiJSUzAiLCJmYWxsYmFja0RhdGUiOiIyMDE5LTA5LTAzIiwicGFpZFVwVG8iOiIyMDIwLTA5LTAyIn0seyJjb2RlIjoiUkMiLCJmYWxsYmFja0RhdGUiOiIyMDE5LTA5LTAzIiwicGFpZFVwVG8iOiIyMDIwLTA5LTAyIn0seyJjb2RlIjoiUkQiLCJmYWxsYmFja0RhdGUiOiIyMDE5LTA5LTAzIiwicGFpZFVwVG8iOiIyMDIwLTA5LTAyIn0seyJjb2RlIjoiUEMiLCJmYWxsYmFja0RhdGUiOiIyMDE5LTA5LTAzIiwicGFpZFVwVG8iOiIyMDIwLTA5LTAyIn0seyJjb2RlIjoiUk0iLCJmYWxsYmFja0RhdGUiOiIyMDE5LTA5LTAzIiwicGFpZFVwVG8iOiIyMDIwLTA5LTAyIn0seyJjb2RlIjoiV1MiLCJmYWxsYmFja0RhdGUiOiIyMDE5LTA5LTAzIiwicGFpZFVwVG8iOiIyMDIwLTA5LTAyIn0seyJjb2RlIjoiREIiLCJmYWxsYmFja0RhdGUiOiIyMDE5LTA5LTAzIiwicGFpZFVwVG8iOiIyMDIwLTA5LTAyIn0seyJjb2RlIjoiREMiLCJmYWxsYmFja0RhdGUiOiIyMDE5LTA5LTAzIiwicGFpZFVwVG8iOiIyMDIwLTA5LTAyIn0seyJjb2RlIjoiUlNVIiwiZmFsbGJhY2tEYXRlIjoiMjAxOS0wOS0wMyIsInBhaWRVcFRvIjoiMjAyMC0wOS0wMiJ9XSwiaGFzaCI6IjE0Mjg5NzUwLzAiLCJncmFjZVBlcmlvZERheXMiOjcsImF1dG9Qcm9sb25nYXRlZCI6ZmFsc2UsImlzQXV0b1Byb2xvbmdhdGVkIjpmYWxzZX0=-Gd8RATyTEnHcAydKuC7N1ZdeLaMP9IR+nlPyVxvLsczAUTGKxcuAYbfz/uVtepg8ey4NfJlPNS+AGcGz8x7ImkX9jEV9KElMxPu3tKSdF/WKo6JCONX7UtudYa/9EQum3banxci/qH7jejSrFZSN+YjWQiYTR0Q8gq4/a2RyQTgseZfpImY/nXkOWLwWArr/p+4ddp/bWQN4nLTW+Z4ZaQeLE96Z9viCdn62EKOcR02Hfr9Oju9VYQh1L8pGrTqNey5nUSv/LQUbVwo5qoYbBRos8l6ewkFNGsuC3vtOgGWSgkgChbDjWhW4Nkm4vDM2NFAphMsS1dgyPw3eJ3C+6A==-MIIElTCCAn2gAwIBAgIBCTANBgkqhkiG9w0BAQsFADAYMRYwFAYDVQQDDA1KZXRQcm9maWxlIENBMB4XDTE4MTEwMTEyMjk0NloXDTIwMTEwMjEyMjk0NlowaDELMAkGA1UEBhMCQ1oxDjAMBgNVBAgMBU51c2xlMQ8wDQYDVQQHDAZQcmFndWUxGTAXBgNVBAoMEEpldEJyYWlucyBzLnIuby4xHTAbBgNVBAMMFHByb2QzeS1mcm9tLTIwMTgxMTAxMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxcQkq+zdxlR2mmRYBPzGbUNdMN6OaXiXzxIWtMEkrJMO/5oUfQJbLLuMSMK0QHFmaI37WShyxZcfRCidwXjot4zmNBKnlyHodDij/78TmVqFl8nOeD5+07B8VEaIu7c3E1N+e1doC6wht4I4+IEmtsPAdoaj5WCQVQbrI8KeT8M9VcBIWX7fD0fhexfg3ZRt0xqwMcXGNp3DdJHiO0rCdU+Itv7EmtnSVq9jBG1usMSFvMowR25mju2JcPFp1+I4ZI+FqgR8gyG8oiNDyNEoAbsR3lOpI7grUYSvkB/xVy/VoklPCK2h0f0GJxFjnye8NT1PAywoyl7RmiAVRE/EKwIDAQABo4GZMIGWMAkGA1UdEwQCMAAwHQYDVR0OBBYEFGEpG9oZGcfLMGNBkY7SgHiMGgTcMEgGA1UdIwRBMD+AFKOetkhnQhI2Qb1t4Lm0oFKLl/GzoRykGjAYMRYwFAYDVQQDDA1KZXRQcm9maWxlIENBggkA0myxg7KDeeEwEwYDVR0lBAwwCgYIKwYBBQUHAwEwCwYDVR0PBAQDAgWgMA0GCSqGSIb3DQEBCwUAA4ICAQAF8uc+YJOHHwOFcPzmbjcxNDuGoOUIP+2h1R75Lecswb7ru2LWWSUMtXVKQzChLNPn/72W0k+oI056tgiwuG7M49LXp4zQVlQnFmWU1wwGvVhq5R63Rpjx1zjGUhcXgayu7+9zMUW596Lbomsg8qVve6euqsrFicYkIIuUu4zYPndJwfe0YkS5nY72SHnNdbPhEnN8wcB2Kz+OIG0lih3yz5EqFhld03bGp222ZQCIghCTVL6QBNadGsiN/lWLl4JdR3lJkZzlpFdiHijoVRdWeSWqM4y0t23c92HXKrgppoSV18XMxrWVdoSM3nuMHwxGhFyde05OdDtLpCv+jlWf5REAHHA201pAU6bJSZINyHDUTB+Beo28rRXSwSh3OUIvYwKNVeoBY+KwOJ7WnuTCUq1meE6GkKc4D/cXmgpOyW/1SmBz3XjVIi/zprZ0zf3qH5mkphtg6ksjKgKjmx1cXfZAAX6wcDBNaCL+Ortep1Dh8xDUbqbBVNBL4jbiL3i3xsfNiyJgaZ5sX7i8tmStEpLbPwvHcByuf59qJhV/bZOl8KqJBETCDJcY6O2aqhTUy+9x93ThKs1GKrRPePrWPluud7ttlgtRveit/pcBrnQcXOl1rHq7ByB8CFAxNotRUYL9IF5n3wJOgkPojMy6jetQA5Ogc8Sm7RG6vg1yow==
```

### 三、更改一些配置

  激活完成后更改一些好用的配置，打开配置页面的方法如下：

![image.png](https://img.hacpai.com/file/2019/11/image-6a90ed5e.png)

#### 1、修改 JDK 路径

![image.png](https://img.hacpai.com/file/2019/11/image-8c44c9fd.png)

  选择本机上的 JDK 路径，推荐使用 JDK8。

![image.png](https://img.hacpai.com/file/2019/11/image-c65d71b3.png)

#### 2、修改字体

![image.png](https://img.hacpai.com/file/2019/11/image-a01fc952.png)

#### 3、修改皮肤颜色

![image.png](https://img.hacpai.com/file/2019/11/image-1d0a3b1b.png)

#### 4、生成 foreach 不换行

  取消勾选 Reformat according style 即可。
![image.png](https://img.hacpai.com/file/2019/11/image-b2699126.png)

#### 5、创建类自动生成注解

![image.png](https://img.hacpai.com/file/2019/12/image-2390651a.png)

**欢迎评论，补充其他好用的配置。**

### 四、好用的插件

  使用一些插件可以提升效率。

![image.png](https://img.hacpai.com/file/2019/11/image-eb89d55c.png)

#### 1、阿里巴巴开发手册

  按照阿里巴巴开发对代码进行审核，提示出不规范的代码。

![image.png](https://img.hacpai.com/file/2019/11/image-10f122c3.png)

#### 2、FindBugs-IDEA

  使用 FindBugs-IDEA 插件可以查找代码中潜在的 bug，[具体使用教程](https://blog.csdn.net/feibendexiaoma/article/details/72821781)

![image.png](https://img.hacpai.com/file/2019/11/image-92e220fc.png)

#### 3、Lombok

  使用 Lombok 可以有效减少 bean 中的代码。

![image.png](https://img.hacpai.com/file/2019/11/image-2905126b.png)

#### 4、翻译工具

  英语不好的朋友可以利用该插件进行翻译代码和控制台中的英文。

![image.png](https://img.hacpai.com/file/2019/11/image-9c9d3b52.png)

#### 5、热部署 JRebel

  使用该插件可以对项目进行热部署，大大提升开发效率。

![image.png](https://img.hacpai.com/file/2019/11/image-d2b43197.png)

###### JRebel 的激活方式

  由于 JRebel 是付费的所以分享一下破解方法：

###### 1）下载激活工具

  首先下载插件，然后下载激活工具，下载完毕后启动。链接：[https://pan.baidu.com/s/1xubymhE7UIGe80x4d2_Tng](https://pan.baidu.com/s/1xubymhE7UIGe80x4d2_Tng) ，提取码：4jv2

###### 2）生成 GUI

  点击生成GUI，网站：http://www.ofmonkey.com/transfer/guid

![image.png](https://img.hacpai.com/file/2019/12/image-78f32a1c.png)


###### 3）填写信息

  将生成的 GUI 以`http://127.0.0.1:8888/GUI`的格式填入 URL 中，下面的邮箱随便填写，然后同意下方的协议，点击激活即可。**注意：点击激活前必须确保激活工具已经启动。**

![image.png](https://img.hacpai.com/file/2019/11/image-77761517.png)

###### 4）设置为离线模式

  最后设置为离线模式即可。

![image.png](https://img.hacpai.com/file/2019/12/image-6136e734.png)
