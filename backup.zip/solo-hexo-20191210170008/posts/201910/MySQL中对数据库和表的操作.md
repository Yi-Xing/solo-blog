title: MySQL中对数据库和表的操作
date: '2019-10-10 22:24:47'
updated: '2019-10-13 09:29:05'
tags: [MySQL]
permalink: /articles/2019/10/10/1570717486901.html
---
![](https://img.hacpai.com/bing/20190914.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、数据库的管理

#### 1、创建数据库

  语法：使用 if not exists 关键字，创建数据库前，先判断数据库是否存在，存在则不创建，增加命令的容错性。if not exists 表示如果不存在，if exists 表示如果存在。

```
create database [if not exists]数据库名;
```

#### 2、数据库的修改

##### 1）修改数据库名

方法一：
  这个是 5.1.23 到 5.1.7 版本可以用的，但是官方不推荐，会有丢失数据的危险。

```
rename database 原库名 to 新库名;
```

方法二：
  首先创建新数据库，然后将旧数据库导出，接着删除旧数据库，最后将数据导入新数据库（一般情况下，也不会去修改数据库名的）。

##### 2）修改数据库的字符集

```
alter database 数据库名 character set 字符编码;
```

#### 3、数据库的删除

```
drop database [if exists] 数据库名;
```

#### 4、其他命令

##### 1）查看数据库

  查看 MySQL 中现在有哪些数据库。

```
show databases;
```

##### 2）进入数据库

```
use 数据库名;
```

##### 3）查看当前所在数据库

```
select database();
```

##### 4）查看数据库的变量值

```
show variables like '%变量名%';
```

### 二、表的管理

#### 1、表的创建

```
create table [if not exists] 表名(
	列名 数据类型 [(长度) 约束],
	列名 数据类型 [(长度) 约束],
	...
	列名 数据类型 [(长度) 约束]
)
```

#### 2、表的修改

##### 1）修改列名

```
alter table 表名 change column 原名 新名 类型 约束;
```

##### 2）修改列的类型或约束

```
alter table 表名 modify column 原名 类型 约束;
```

##### 3）添加新列

```
alter table 表名 add column 列名 类型 约束;
```

##### 4）删除列

```
alter table 表名 drop column 列名;
```

##### 5）修改表名

```
alter table 原表名 rename to 新表名;
```

#### 3、表的删除

```
drop table [if exists] 表名;
```

#### 4、表的复制

##### 1）仅仅复制表结构

```
create table 新表名 like 被复制表名; 
```

##### 2）复制表的结构 + 数据

  复制的数据根据 select 语句决定，如果只想要部分数据则加上 where 语句。

```
create table 新表名
select *
from 被复制表名;
```

  例如：仅仅复制某些字段，where 条件恒为假，所以没有匹配的数据。

```
create table 新表名
select 字段1,字段2
from 被复制表名
where 1=2;
```

#### 5、其他命令

##### 1）查看表

  ①查看当前数据库中有那些表。

```
show tables;
```

  ②查看指定数据库中有那些表。

```
show tables from 数据库名;
```

##### 2）查看表结构

```
desc 表名;
```

##### 3）查看表的创建信息
```
show create table 表名;
```
##### 4）查看表中的所有的索引
```
show index from 表名;
```
