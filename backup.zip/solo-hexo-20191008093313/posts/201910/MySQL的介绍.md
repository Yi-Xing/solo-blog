title: MySQL的介绍
date: '2019-10-07 11:26:16'
updated: '2019-10-07 17:52:03'
tags: [MySQL]
permalink: /articles/2019/10/07/1570418776092.html
---
![](https://img.hacpai.com/bing/20180812.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、概念

#### 1、数据库

  DB 数据库（Database），存储数据的仓库，它保存一系列有组织的数据库。
  DBMS 数据库管理系统（Database Management System），数据库是通过 DBMS 创建和操作的容器。

#### 2、SQL

  SQL 结构化查询语言（Structure Query Language），专门用来与数据库通信的语言。SQl 不是某个特定数据库供应商专有的语言，几乎所有的 DBMS 都支持 SQL。
  DDL 数据定义语言，用来定义数据库对象：数据库，表，列等等。关键字：create，alter，drop 等。
  DML 数据操作语言，用来对数据库中表中的记录进行操作。关键字：insert，delete，update 等。
  DCL 数据控制语言，用来定义数据库的访问权限，安全级别等。
  DQL 数据查询语言，用来查询数据库的记录，关键字：select，from，where 等。

### 二、配置文件

   MySQL 的配置文件是 my.imi，我们只需要对 mysqld 下面的配置进行操作，修改后必须重启 MySQL 才会生效。

```
# 我的 my.imi 的配置
[client]

# pipe=

# socket=MYSQL

port=3306

[mysql]
no-beep

# default-character-set=

# SERVER SECTION
# ----------------------------------------------------------------------
#
# The following options will be read by the MySQL Server. Make sure that
# you have installed the server correctly (see above) so it reads this 
# file.
#
# server_type=3
# mysqld是关于mysql服务器端的配置
[mysqld]

# The next three options are mutually exclusive to SERVER_PORT below.
# skip-networking
# enable-named-pipe
# shared-memory

# shared-memory-base-name=MYSQL

# The Pipe the MySQL Server will use
# socket=MYSQL

# The TCP/IP Port the MySQL Server will listen on
# MySQL启动后占用的端口号，默认是3306
port=3306

# Path to installation directory. All paths are usually resolved relative to this.
# MySQL的安装路径
# basedir="C:/Program Files/MySQL/MySQL Server 8.0/"

# Path to the database root
# MySQL的数据存储路径
datadir=C:/ProgramData/MySQL/MySQL Server 8.0/Data

# The default character set that will be used when a new schema or table is
# created and no character set is defined
# character-set-server=

# The default authentication plugin to be used when connecting to the server
default_authentication_plugin=caching_sha2_password

# The default storage engine that will be used when create new tables when
# 数据库存储引擎
default-storage-engine=INNODB

# Set the SQL mode to strict
# 语法模式
sql-mode="STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION"

# General and Slow logging.
log-output=FILE
general-log=0
general_log_file="LAPTOP-MJQ1613H.log"
slow-query-log=1
slow_query_log_file="LAPTOP-MJQ1613H-slow.log"
long_query_time=10

# Binary Logging.
log-bin="LAPTOP-MJQ1613H-bin"

# Error Logging.
log-error="LAPTOP-MJQ1613H.err"

# Server Id.
server-id=1

# Indicates how table and database names are stored on disk and used in MySQL.
# Value = 0: Table and database names are stored on disk using the lettercase specified in the
#            CREATE TABLE or CREATE DATABASE statement. Name comparisons are case sensitive.
#            You should not set this variable to 0 if you are running MySQL on a system that has
#            case-insensitive file names (such as Windows or macOS).
# Value = 1: Table names are stored in lowercase on disk and name comparisons are not
#            case-sensitive. MySQL converts all table names to lowercase on storage and lookup.
#            This behavior also applies to database names and table aliases.
# Value = 3, Table and database names are stored on disk using the lettercase specified in the
#            CREATE TABLE or CREATE DATABASE statement, but MySQL converts them to lowercase on
#            lookup. Name comparisons are not case sensitive. This works only on file systems
#            that are not case-sensitive! InnoDB table names and view names are stored in
#            lowercase, as for Value = 1.
# NOTE: lower_case_table_names can only be configured when initializing the server.
#       Changing the lower_case_table_names setting after the server is initialized is prohibited.
lower_case_table_names=1

# Secure File Priv.
secure-file-priv="C:/ProgramData/MySQL/MySQL Server 8.0/Uploads"

# The maximum amount of concurrent sessions the MySQL server will
# allow. One of these connections will be reserved for a user with
# SUPER privileges to allow the administrator to login even if the
# connection limit has been reached.
# MySQL 的最大连接数
max_connections=500

# The number of open tables for all threads. Increasing this value
# increases the number of file descriptors that mysqld requires.
# Therefore you have to make sure to set the amount of open files
# allowed to at least 4096 in the variable "open-files-limit" in
# section [mysqld_safe]
table_open_cache=2000

# Maximum size for internal (in-memory) temporary tables. If a table
# grows larger than this value, it is automatically converted to disk
# based table This limitation is for a single table. There can be many
# of them.
tmp_table_size=43M

# How many threads we should keep in a cache for reuse. When a client
# disconnects, the client's threads are put in the cache if there aren't
# more than thread_cache_size threads from before.  This greatly reduces
# the amount of thread creations needed if you have a lot of new
# connections. (Normally this doesn't give a notable performance
# improvement if you have a good thread implementation.)
thread_cache_size=10

#*** MyISAM Specific options
# The maximum size of the temporary file MySQL is allowed to use while
# recreating the index (during REPAIR, ALTER TABLE or LOAD DATA INFILE.
# If the file-size would be bigger than this, the index will be created
# through the key cache (which is slower).
myisam_max_sort_file_size=100G

# If the temporary file used for fast index creation would be bigger
# than using the key cache by the amount specified here, then prefer the
# key cache method.  This is mainly used to force long character keys in
# large tables to use the slower key cache method to create the index.
myisam_sort_buffer_size=76M

# Size of the Key Buffer, used to cache index blocks for MyISAM tables.
# Do not set it larger than 30% of your available memory, as some memory
# is also required by the OS to cache rows. Even if you're not using
# MyISAM tables, you should still set it to 8-64M as it will also be
# used for internal temporary disk tables.
key_buffer_size=8M

# Size of the buffer used for doing full table scans of MyISAM tables.
# Allocated per thread, if a full scan is needed.
read_buffer_size=64K

read_rnd_buffer_size=256K

#*** INNODB Specific options ***
# innodb_data_home_dir=

# Use this option if you have a MySQL server with InnoDB support enabled
# but you do not plan to use it. This will save memory and disk space
# and speed up some things.
# skip-innodb

# If set to 1, InnoDB will flush (fsync) the transaction logs to the
# disk at each commit, which offers full ACID behavior. If you are
# willing to compromise this safety, and you are running small
# transactions, you may set this to 0 or 2 to reduce disk I/O to the
# logs. Value 0 means that the log is only written to the log file and
# the log file flushed to disk approximately once per second. Value 2
# means the log is written to the log file at each commit, but the log
# file is only flushed to disk approximately once per second.
innodb_flush_log_at_trx_commit=1

# The size of the buffer InnoDB uses for buffering log data. As soon as
# it is full, InnoDB will have to flush it to disk. As it is flushed
# once per second anyway, it does not make sense to have it very large
# (even with long transactions).
innodb_log_buffer_size=1M

# InnoDB, unlike MyISAM, uses a buffer pool to cache both indexes and
# row data. The bigger you set this the less disk I/O is needed to
# access data in tables. On a dedicated database server you may set this
# parameter up to 80% of the machine physical memory size. Do not set it
# too large, though, because competition of the physical memory may
# cause paging in the operating system.  Note that on 32bit systems you
# might be limited to 2-3.5G of user level memory per process, so do not
# set it too high.
innodb_buffer_pool_size=8M

# Size of each log file in a log group. You should set the combined size
# of log files to about 25%-100% of your buffer pool size to avoid
# unneeded buffer pool flush activity on log file overwrite. However,
# note that a larger logfile size will increase the time needed for the
# recovery process.
innodb_log_file_size=48M

# Number of threads allowed inside the InnoDB kernel. The optimal value
# depends highly on the application, hardware as well as the OS
# scheduler properties. A too high value may lead to thread thrashing.
innodb_thread_concurrency=17

# The increment size (in MB) for extending the size of an auto-extend InnoDB system tablespace file when it becomes full.
innodb_autoextend_increment=64

# The number of regions that the InnoDB buffer pool is divided into.
# For systems with buffer pools in the multi-gigabyte range, dividing the buffer pool into separate instances can improve concurrency,
# by reducing contention as different threads read and write to cached pages.
innodb_buffer_pool_instances=8

# Determines the number of threads that can enter InnoDB concurrently.
innodb_concurrency_tickets=5000

# Specifies how long in milliseconds (ms) a block inserted into the old sublist must stay there after its first access before
# it can be moved to the new sublist.
innodb_old_blocks_time=1000

# It specifies the maximum number of .ibd files that MySQL can keep open at one time. The minimum value is 10.
innodb_open_files=300

# When this variable is enabled, InnoDB updates statistics during metadata statements.
innodb_stats_on_metadata=0

# When innodb_file_per_table is enabled (the default in 5.6.6 and higher), InnoDB stores the data and indexes for each newly created table
# in a separate .ibd file, rather than in the system tablespace.
innodb_file_per_table=1

# Use the following list of values: 0 for crc32, 1 for strict_crc32, 2 for innodb, 3 for strict_innodb, 4 for none, 5 for strict_none.
innodb_checksum_algorithm=0

# The number of outstanding connection requests MySQL can have.
# This option is useful when the main MySQL thread gets many connection requests in a very short time.
# It then takes some time (although very little) for the main thread to check the connection and start a new thread.
# The back_log value indicates how many requests can be stacked during this short time before MySQL momentarily
# stops answering new requests.
# You need to increase this only if you expect a large number of connections in a short period of time.
back_log=80

# If this is set to a nonzero value, all tables are closed every flush_time seconds to free up resources and
# synchronize unflushed data to disk.
# This option is best used only on systems with minimal resources.
flush_time=0

# The minimum size of the buffer that is used for plain index scans, range index scans, and joins that do not use
# indexes and thus perform full table scans.
join_buffer_size=256K

# The maximum size of one packet or any generated or intermediate string, or any parameter sent by the
# mysql_stmt_send_long_data() C API function.
max_allowed_packet=4M

# If more than this many successive connection requests from a host are interrupted without a successful connection,
# the server blocks that host from performing further connections.
max_connect_errors=100

# Changes the number of file descriptors available to mysqld.
# You should try increasing the value of this option if mysqld gives you the error "Too many open files".
open_files_limit=4161

# If you see many sort_merge_passes per second in SHOW GLOBAL STATUS output, you can consider increasing the
# sort_buffer_size value to speed up ORDER BY or GROUP BY operations that cannot be improved with query optimization
# or improved indexing.
sort_buffer_size=256K

# The number of table definitions (from .frm files) that can be stored in the definition cache.
# If you use a large number of tables, you can create a large table definition cache to speed up opening of tables.
# The table definition cache takes less space and does not use file descriptors, unlike the normal table cache.
# The minimum and default values are both 400.
table_definition_cache=1400

# Specify the maximum size of a row-based binary log event, in bytes.
# Rows are grouped into events smaller than this size if possible. The value should be a multiple of 256.
binlog_row_event_max_size=8K

# If the value of this variable is greater than 0, a replication slave synchronizes its master.info file to disk.
# (using fdatasync()) after every sync_master_info events.
sync_master_info=10000

# If the value of this variable is greater than 0, the MySQL server synchronizes its relay log to disk.
# (using fdatasync()) after every sync_relay_log writes to the relay log.
sync_relay_log=10000

# If the value of this variable is greater than 0, a replication slave synchronizes its relay-log.info file to disk.
# (using fdatasync()) after every sync_relay_log_info transactions.
sync_relay_log_info=10000

# Load mysql plugins at start."plugin_x ; plugin_y".
# plugin_load

# The TCP/IP Port the MySQL Server X Protocol will listen on.
loose_mysqlx_port=33060
```

### 三、MySQL 的语法规范

  1、不区分大小写，但是建议关键字大写，表名，列名小写。
  2、每条语句用分号结尾。
  3、命令可以随意缩进和换行。
  4、字符型使用单引号或双引号包裹。
  5、注释
    单行注释
      # 注释文本
      -- 注释文本
    多行注释
      /* 注释文本 */

### 四、MySQL 的常用命令

  平时大多使用图形化界面进行操作，对 MySQL 的命令渐渐淡忘，在此进行记录。以下命名属于 MySQL 命名，不受平台限制。

#### 1) 登录

  地址指的是 IP、域名，本机可以不写或 localhost，-P 表示端口号不写默认 3306，-u 表示用户名，-p 后回车然后输入密码。

```
mysql -h地址 -P3306 -uroot -p
```

**下面的命令都是在 MySQL 命令框中执行。**

#### 2）查看版本

```
selcet version()
```

#### 3）查看数据库

  查看 MySQL 中现在有哪些数据库。

```
show database
```

#### 4）进入数据库

```
usr 数据库名
```

#### 5）查看当前所在数据库

```
select database()
```

#### 6）查看表

  ①查看当前数据库中有那些表

```
show tables
```

  ②查看指定数据库中有那些表

```
show tables from 数据库名
```

#### 7）查看表结构

```
desc 表名
```

#### 8）退出MySQL 命令框

```
exit
```
### 五、MySQL 的思维导图
&emsp;&emsp;这也是我今后的MySQL学习路线。
![mysql.png](https://img.hacpai.com/file/2019/10/mysql-75182c45.png)

