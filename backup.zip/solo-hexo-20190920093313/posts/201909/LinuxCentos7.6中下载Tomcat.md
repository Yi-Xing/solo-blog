title: Linux（Centos7.6）中下载Tomcat
date: '2019-09-19 17:45:50'
updated: '2019-09-20 09:25:10'
tags: [Tomcat, Linux]
permalink: /articles/2019/09/19/1568886350347.html
---
![](https://img.hacpai.com/bing/20180819.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 1、下载Tomcat
[下载Tomcat的官网](https://tomcat.apache.org/download-80.cgi#8.5.45)

1）下载Tomcat
```
wget http://mirrors.tuna.tsinghua.edu.cn/apache/tomcat/tomcat-8/v8.5.45/bin/apache-tomcat-8.5.45.tar.gz
```
2）解压Tomcat
```
tar -zxvf apache-tomcat-8.5.45.tar.gz
```
### 2、启动Tomcat

1）查看Tomcat运行状态
```
ps -ef|grep java 
```
**在Tomcat的bin目录下执行**
2）启动
```
./startup.sh
```
3）关闭
``` 
./shutdown.sh
```
### 3、测试Tomcat是否启动成功
在浏览器中访问http://ip:8080 如果显示以下页面表示启动成功。
**注意：8080端口是Tomcat的默认端口号，具体查看server.xml配置文件。**
![tomcat.png](https://img.hacpai.com/file/2019/09/tomcat-4e461100.png)

如果没有显示不要着急可能是端口没有开放。

1）首先查看已开放的端口
```
firewall-cmd --list-ports
```
2）开启端口（重启防火墙后生效，阿里云服务器还需要在控制台打开端口）
```
firewall-cmd --zone=public --add-port=8080/tcp --permanent
命令含义：
–zone #作用域
–add-port=80/tcp #添加端口，格式为：端口/通讯协议
–permanent #永久生效，没有此参数重启后失效
```
3）关闭端口（重启防火墙后生效）
```
firewall-cmd --zone=public --remove-port=9200/tcp --permanent
```
4）启动防火墙
```
systemctl start firewalld 
```
5）开机启用防火墙  
```
systemctl enable firewalld.service
```
6）重启防火墙
```
firewall-cmd --reload 
```
7）关闭firewall
```
systemctl stop firewalld.service 
```
### 4、设置Tomcat开启自动启动

1）在/etc/init.d目录下，新建一个tomcat文件，添加内容：
```
#!/bin/sh
# chkconfig: 345 99 10
# description: Auto-starts tomcat
# /etc/init.d/tomcat
# Tomcat auto-start
# Source function library.
#. /etc/init.d/functions
# source networking configuration.
#. /etc/sysconfig/network
RETVAL=0
# 填写自己JDK的路径
export JRE_HOME=/usr/develop/java/jdk1.8.0_181/jre
# 填写自己的Tomcat的路径
export CATALINA_HOME=/usr/develop/tomcat/apache-tomcat-8.5.45
export CATALINA_BASE=/usr/develop/tomcat/apache-tomcat-8.5.45
start()
{
        if [ -f $CATALINA_HOME/bin/startup.sh ];
          then
            echo $"Starting Tomcat"
                $CATALINA_HOME/bin/startup.sh
            RETVAL=$?
            echo " OK"
            return $RETVAL
        fi
}
stop()
{
        if [ -f $CATALINA_HOME/bin/shutdown.sh ];
          then
            echo $"Stopping Tomcat"
                $CATALINA_HOME/bin/shutdown.sh
            RETVAL=$?
            sleep 1
            ps -fwwu tomcat | grep apache-tomcat|grep -v grep | grep -v PID | awk '{print $2}'|xargs kill -9
            echo " OK"
            # [ $RETVAL -eq 0 ] && rm -f /var/lock/...
            return $RETVAL
        fi
}

case "$1" in
 start) 
        start
        ;;
 stop)  
        stop
        ;;
                                                
 restart)
         echo $"Restaring Tomcat"
         $0 stop
         sleep 1
         $0 start
         ;;
 *)
        echo $"Usage: $0 {start|stop|restart}"
        exit 1
        ;;
esac
exit $RETVAL
```
2）添加执行权限
```
sudo chmod +x /etc/init.d/tomcat
```
3）设置随系统启动
```
chkconfig --add tomcat
```
