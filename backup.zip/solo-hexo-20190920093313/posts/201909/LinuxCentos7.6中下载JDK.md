title: Linux（Centos7.6）中下载JDK
date: '2019-09-19 17:15:24'
updated: '2019-09-20 09:21:56'
tags: [JavaSE, Linux]
permalink: /articles/2019/09/19/1568884524004.html
---
![](https://img.hacpai.com/bing/20180113.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 1、下载 JDK

[下载JDK8的官网](https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)
&emsp;&emsp;下载自己想要的 JDK 版本，然后通过 Xftp、FinalShell 等工具将文件传输到 Linux 上。
![image.png](https://img.hacpai.com/file/2019/09/image-68334af9.png)

### 2、解压 JDK
```
tar -zxvf  jdk-8u181-linux-x64.tar.gz
```
### 3、配置环境变量
1）这个文件是每个用户登录时都会运行的环境变量设置  
```
vi /etc/profile
```
2）在文件尾部添加以下内容
```
# 自己的JDK的路径
export Java_HOME=/usr/Java/jdk1.8.0_181
export JRE_HOME=${Java_HOME}/jre
export CLASSPATH=.:${Java_HOME}/lib:${JRE_HOME}/lib:$CLASSPATH
export Java_PATH=${Java_HOME}/bin:${JRE_HOME}/bin
export PATH=$PATH:${Java_PATH}
```
3）执行命令或重启机器
```
source /etc/profile
```
### 4、测试
查看 Java 版本，验证配置是否成功
```
Java -version
```
如果显示以下信息表示配置正确。
![image.png](https://img.hacpai.com/file/2019/09/image-842c17bc.png)


