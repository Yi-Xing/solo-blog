title: MySQL中的分组查询
date: '2019-10-08 15:52:56'
updated: '2019-10-09 20:09:01'
tags: [MySQL]
permalink: /articles/2019/10/08/1570521176176.html
---
![](https://img.hacpai.com/bing/20190819.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、作用
&emsp;&emsp;分组查询用于将数据库中的数据按指定列进行分组，使用 group  by 子句将表中的数据分为若干组。
### 二、语法
```
select 查询列表 
form 表名 
[where 筛选条件] 
[group by 分组列表
[having 分组条件] ]
[order by 排序列表 [asc|desc] ] ;
```

### 三、例子
&emsp;&emsp;表名为 user
#### 1、表结构

|名|类型|长度|键|
|:---:|:---:|:---:|:---:|
|id|int|11|主键|
|name|varchar|255|无|
|age|int|255|无|
|class|varchar|11|无|

#### 2、数据表

|id|name|age|class|
|:---:|:---:|:---:|:---:|
|1|zyx|100|一班|
|2|wmj|222|二班|
|3|zyx6|110|二班|
|4|zyx1|80|一班|
|5|zyx2|70|一班|
|6|zyx3|120|二班|
|7|zyx4|130|一班|

#### 3、实例
##### 1）统计每个班级的人数

```
select class,count(*) as 人数 
from user 
group by class;
```

&emsp;&emsp;运行结果：

|class|人数|
|:---:|:---:|
|一班|4|
|二班|3|

##### 2）分组显示每个班级的所有学生信息
&emsp;&emsp;group by 和 group_concat 函数结合使用。

```
select group_concat(id) id,group_concat(name) name,class 
from user 
group by class;
```
&emsp;&emsp;运行结果：

|id|name|class|
|:---:|:---:|:---:|
|1,4,5,7|zyx,zyx1,zyx2,zyx4|一班|
|2,3,6|wmj,zyx6,zyx3|二班|

##### 3）获取每个班中年龄大于 110 的学生

```
select group_concat(id) id,group_concat(name) name,class 
from user 
where age>110
group by class
```

&emsp;&emsp;运行结果：

|id|name|class|
|:---:|:---:|:---:|
|7|zyx4|一班|
|2,6|wmj,zyx3|二班|

##### 4）显示平均年龄大于 100 的班级

```
select class   
from user   
group by class  
having avg(age)>100  
```

&emsp;&emsp;运行结果：

|class|
|:---:|
|二班|

### 四、筛选条件的分类
&emsp;&emsp;分组查询中的筛选条件分为两类

||数据源|位置|关键字|
|:---:|:---:|:---:|:---:|
|分组前筛选|原始表|在 group by 前|where|
|分组后筛选|分组后的结果集|在 group by 后|having|

