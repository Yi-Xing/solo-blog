title: 重学Maven——使用 Nexus 搭建私服并上传下载 Jar 包
date: '2019-11-04 19:28:31'
updated: '2019-11-11 21:28:26'
tags: [JavaWeb, Maven]
permalink: /articles/2019/11/04/1572866911213.html
---
![](https://img.hacpai.com/bing/20190208.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、介绍

  Nexus 是一个强大的 maven 仓库管理器,它极大的简化了本地内部仓库的维护和外部仓库的访问。它是一个简单文件系统而非数据库。

### 二、Nexus 作用

#### 1、提高下载速度

  Nexus 作为私有库部署在局域网内部。假如多个人协同开发，开发人员 A 需要一个 log4j 的 jar 来实现系统日志功能，A 将 log4j 的坐标添加到自己模块的 pom 文件中，maven 会向公共仓库发送请求，下载 log4j 的 jar 包。下载的过程中，Nexus 也偷偷的保存了一份 log4j 在私有的仓库。那么以后再有开发人员需要 log4j 的时候，请求是直接发送到 Nexus 上请求资源的。就不需要访问外网了，否则每个人都需要访问公共 Maven 库下载资源。这样节省了流量，同时内网的网速一般也比公网快。也提高了工作效率。

#### 2、提高开发效率

  多人协同开发，A 开发系统管理、B 开发考勤模块。考勤模块依赖了系统管理的员工接口，那么 B 需要手动拷贝 A 打包的 jar 到自己的工程中。当 A 改动了系统管理的接口，B 完全不知情，等出现问题了还需要联调，很麻烦！有了 Nexus A 就可以将系统管理打包发布到 Nexus 的私有仓库中，B 添加系统管理的坐标即可完成依赖，以后 A 再有改动，只要发布到 Nexus 上就可以了。减少了沟通成本。

### 三、Nexus 的下载与启动

#### 1、下载 Nexus（Windows 或 Linux）

  Nexus Repository Manager 仓库管理有 2 个版本，专业版和 oss 版，oss 版是免费的，专业版是收费的，我们使用 oss 版。

* 官网地址：[https://www.sonatype.com](https://www.sonatype.com)
* 官网文档：[https://help.sonatype.com/docs](https://help.sonatype.com/docs)
* 下载地址：[https://www.sonatype.com/download-nexus-repo-oss](https://www.sonatype.com/download-nexus-repo-oss)
* 官网下载很慢，可以使用百度网盘下载：
  链接：https://pan.baidu.com/s/1nyUqltbF9_QTHFDwG7z7yw 
  提取码：n27c 

#### 2、Windows 中启动 Nexus

  下载完毕后解压，然后以**管理员身份**运行 DOS 命令窗口，切换到 Nexus 的 bin 目录下，执行：

```
nexus.exe /run
```

  执行后如果显示以下信息，表示执行成功，如果没有启动成功则看该博客底部的`异常处理`。

```
-------------------------------------------------

Started Sonatype Nexus OSS 3.9.0-01

-------------------------------------------------
```

#### 3、Linux 中启动 Nexus
  下载完毕后解压，切换到 Nexus 的 bin 目录下，执行以下命令。
  使用`run`启动可以看见具体的启动信息。
```
./nexus run
```
  使用`start`启动只有少量的提示信息。
```
./nexus start
```
&emsp;&emsp;其他命令。
~~~
 ./nexus {start|stop|run|run-redirect|status|restart|force-reload}
~~~
**提示信息：**

  如果运行后提示以下信息，表示 Nexus 不建议使用root用户启动，但是并不影响Nexus启动。

~~~
WARNING: ************************************************************
WARNING: Detected execution as "root" user.  This is NOT recommended!
WARNING: ************************************************************
~~~

  如果运行后提示以下信息表示内存溢出，即内存不够（只有使用`run`运行才能看到）。

~~~
2019-11-11 19:46:49,841+0800 WARN  [jetty-main-1] *SYSTEM org.eclipse.jetty.webapp.WebAppContext - Failed startup of context o.e.j.w.WebAppContext@655c293a{Sonatype Nexus,/nexus,file:///usr/develop/nexus/nexus3/public/,UNAVAILABLE}
java.lang.OutOfMemoryError: Java heap space
        at java.lang.Object.clone(Native Method)
        at org.apache.felix.resolver.util.OpenHashMap.clone(OpenHashMap.java:820)
...
~~~

**解决办法：**

  修改配置文件将最大内存设置小点，打开`nexus.vmoptions`。

![image.png](https://img.hacpai.com/file/2019/11/image-15b6e84b.png)

&emsp;&emsp;Nexus 运行默认需要的内存：

~~~
-Xms1200M
-Xmx1200M 
-XX:MaxDirectMemorySize=2G
~~~
&emsp;&emsp;将最大内存设置小点，但是不能太小。然后重新运行即可。
~~~
# -Xms128M -Xmx128M  -XX:MaxDirectMemorySize=256M  不能用太少
-Xms256M 
-Xmx512M 
-XX:MaxDirectMemorySize=1024M
~~~

#### 4、验证是否启动成功

  启动成功后，访问：http://localhost:8081/ 。然后点击`Sigin in`登录，默认的账号：`admin`，密码：`admin123`。[用户界面详解（官方文档）](https://help.sonatype.com/repomanager3/user-interface)。  
  
![image.png](https://img.hacpai.com/file/2019/11/image-ab61a2fd.png)

#### 5、修改端口号  
  
##### ① 打开 nexus-default.properties 文件  
![image.png](https://img.hacpai.com/file/2019/11/image-bb268cda.png)  
  
##### ② 修改端口，端口号默认为：8081  
  
![image.png](https://img.hacpai.com/file/2019/11/image-fae487a8.png)  
  
#### 6、修改密码  
  
&emsp;&emsp;登录后，点击`Change password`修改密码。  
  
![image.png](https://img.hacpai.com/file/2019/11/image-27e29574.png)
### 四、Nexus 的仓库

#### 1、仓库类型：

* `proxy`：代理仓库，被用来代理远程的仓库，如 Maven 的中央仓库，阿里的镜像。
* `hosted`：本地仓库，用于存放本公司开发的 jar 包（正式版本、测试版本）。
* `group`:仓库组，使用时连接的仓库，包含 Hosted（宿主仓库）和 Proxy（代理仓库），通常用来配置 maven 依赖的仓库。

![image.png](https://img.hacpai.com/file/2019/11/image-902558b2.png)

#### 2、使用阿里的镜像

   将`proxy`（代理仓库）访问的地址改为阿里的镜像地址，默认为 Maven 的中央仓库，修改前必须先登录。

![image.png](https://img.hacpai.com/file/2019/11/image-12ecbd5e.png)

#### 3、Releases 和 Snapshots 的区别

  我们不难发现默认的`maven-public`（仓库组）中包含俩个`hosted`（本地仓库）分别是`maven-releases`和`maven-snapshots`。
  `Releases`用于存放自己项目中发布的构建， 通常是 `Release` 版本的。比如我们开发一个项目，可以将这个项目打包发布到 Nexus 的 `Releases` 本地仓库中，关于如何发布后面会有介绍。
  `Snapshots`这个仓库非常有用，它用于存放那些非 `Release` 版本即非稳定版本的依赖。比如多人同时开发一个项目，在正式的 `Release` 之前你可能需要临时发布一个版本的依赖给同伴使用。那么这个时候我们就可以发布 `Snapshot` 版本到这个仓库，你的同伴就可以通过简单的命令也获取和使用这个临时版本的依赖。

### 五、使用 Nexus 下载 Jar 包

#### 1、远程仓库的认证

  大部分公共的远程仓库无须认证就可以直接访问，但我们在平时的开发中往往会架设自己的 Maven 远程仓库，出于安全方面的考虑，我们需要提供认证信息才能访问这样的远程仓库。配置认证信息和配置远程仓库不同，远程仓库可以配置在 settings.xml 文件中，也可直接在 pom.xml 中配置，后面会分别举例说明，但是认证信息必须配置在 settings.xml 文件中。配置方式如下

```xml
<server>
  <id>zyxwmj.top</id>
  <username>admin</username>
  <password>admin123</password>
</server>
```

#### 2、在 settings.xml 的 mirrors 标签下配置

  使用 mirror 配置可以强制将所有包请求都会被转向内网 Nexus 服务器的地址。

```xml
<mirrors>	
   <mirror>
      <!--和server的id对应-->
      <id>zyxwmj.top</id>
      <mirrorOf>*</mirrorOf>
      <url>http://localhost:8081/repository/maven-public/</url>
   </mirror>
 </mirrors>
```

#### 3、在 pom.xml 的 repositories 下配置

```
<repositories>
   <repository>
      <!--和server的id对应-->
      <id>zyxwmj.top</id>
      <!--自己仓库的URL-->
      <url>http://localhost:8081/repository/maven-public/</url>
      <layout>default</layout>
      <!--是否开启发布版构件下载-->
      <releases>
         <enabled>true</enabled>
      </releases>
      <!--是否开启快照版构件下载-->
      <snapshots>
         <enabled>false</enabled>
      </snapshots>
   </repository>
</repositories>
```


#### 4、在 settings.xml 或 pom.xml 的 profiles 标签下配置
```
<profiles>
    <profile>
        <id>nexusProfile</id>
        <activation>
            <!-- 设置默认激活 -->
            <activeByDefault>true</activeByDefault>
        </activation>
        <repositories>
            <repository>
                <id>zyxwmj.top</id>
                <url>http://localhost:8081/repository/maven-public/</url>
                <layout>default</layout>
                <releases>
                    <enabled>true</enabled>
                </releases>
                <!-- snapshots默认是关闭的false,必须显示的打开 -->
                <snapshots>
                    <enabled>true</enabled>
                </snapshots>
            </repository>
        </repositories>
    </profile>
</profiles>
```
### 六、将 Jar 包上传到 Nexus 的仓库中

#### 1、手动上传

**① 首先登录，然后点击需要上传 Jar 包的本地仓库。**

![image.png](https://img.hacpai.com/file/2019/11/image-5b82f720.png)

**② 接着点击上传组件。**

![image.png](https://img.hacpai.com/file/2019/11/image-38afc875.png)

**③ 选择文件，输入文件扩展名等相关信息后，点击上传即可。**

![image.png](https://img.hacpai.com/file/2019/11/image-d0f7e4d3.png)

**④ 我们可以看到自己刚刚上传的 Jar 包。**

![image.png](https://img.hacpai.com/file/2019/11/image-011d2a77.png)

#### 2、命令上传

**① 首先在 Maven 配置文件中配置 Nexus 的管理员密码**

```xml
<server>
  <id>zyxwmj.top</id>
  <username>admin</username>
  <password>admin123</password>
</server>
```

**② 在 Maven 环境中输入命令**

```
mvn deploy:deploy-file -DgroupId=top -DartifactId=zyxwmj -Dversion=3.0 -Dpackaging=jar -Dfile=F:/test.jar -Durl=http://localhost:8081/repository/maven-releases/ -DrepositoryId=zyxwmj.top
```

**mvn deploy:deploy-file 命令的参数说明**

* -DgroupId=xxxxxx 就相当于 pom 中的 groupId
* -DartifactId=xxxxxx 就相当于 pom 中的 artifactId
* -Dversion=xxxxxx 就相当于 pom 中的版本号 version
* -Dpackaging=xxxxxx 就相当于 pom 中打包方式
* -Dfile=xxxxxx 本地环境
* -Durl=xxxxxx 上传的 url，指定本地仓库
* -DrepositoryId=xxxxxx 对应的是 setting.xml 里边的 id
* -DpomFile=xxxxxx 对应的是 pom 文件路径

#### 3、配置文件 + 命令进行上传 releases 版本

　　在需要上传的 pom.xml 中增加`<distributionManagement>`配置。

```
<distributionManagement>
    <repository>
        <id>zyxwmj.top</id>
        <url>http://localhost:8081/repository/maven-releases/</url>
    </repository>
</distributionManagement>
```

　　然后在项目的根目录使用该命令（如果出错则去看博客底部的`异常处理`）。

```
mvn deploy
```

#### 4、配置文件 + 命令进行上传 snapshot 版本

  执行命令后默认是上传到`releases`仓库中。所以需要在版本号后面加上`-SNAPSHOT`。

```xml
<version>1.0-SNAPSHOT</version>
```

　　在需要上传的 pom.xml 中增加`<distributionManagement>`配置。

```
<distributionManagement>
    <snapshotRepository>
        <id>zyxwmj.top</id>
        <url>http://localhost:8081/repository/maven-snapshots/</url>
    </snapshotRepository>
</distributionManagement>
```

　　然后在项目的根目录使用该命令（如果出错则去看博客底部的`异常处理`）。

```
mvn deploy
```

### 七、异常处理

#### 1、启动失败

  如果启动失败报以下错误信息，则打开 Nexus 的安装目录 ，可以看见 `nexus-3.9.0-01`和`sonatype-work`文件夹。打开`sonatype-work`文件夹，将`nexus3`重命名或删除，重新启动即可。

```java
2019-11-05 14:43:17,010+0800 ERROR [FelixStartLevel <command>sql.UPDATE quartz_job_detail SET value_data.jobDataMap.restoreBlobs = 'true' WHERE value_data.jobDataMap['.typeId'] = 'blobstore.rebuildComponentDB'</command>] *SYSTEM ROOT - Exception `60178F50` in storage `plocal:F:/develop/nexus-3.9.0-01/sonatype-work/nexus3/db/config`: 2.2.31 (build 285537d2767275f460df32c6a3be01bfff6a517c, branch 2.2.x)
com.orientechnologies.orient.core.exception.OQueryParsingException: Error on parsing query at position #18: Error on parsing query
Query:  quartz_job_detail WHERE value_data.jobDataMap['.typeId'] = 'blobstore.rebuildComponentDB'
-----------------------^
        DB name="config"
        at com.orientechnologies.orient.core.sql.filter.OSQLTarget.<init>(OSQLTarget.java:74)
...
```

#### 2、启动后报错

  如果启动后，报以下错误信息：

```java
2019-11-05 14:48:59,664+0800 WARN  [pool-21-thread-2] anonymous com.sonatype.nexus.plugins.outreach.internal.outreach.SonatypeOutreach - Could not download page bundle
org.apache.http.conn.ConnectTimeoutException: Connect to download.sonatype.com:443 [download.sonatype.com/52.5.90.225, download.sonatype.com/52.45.118.106] failed: Read timed out
        at org.apache.http.impl.conn.DefaultHttpClientConnectionOperator.connect(DefaultHttpClientConnectionOperator.java:150)
        at org.apache.http.impl.conn.PoolingHttpClientConnectionManager.connect(PoolingHttpClientConnectionManager.java:353)
        at org.apache.http.impl.execchain.MainClientExec.establishRoute(MainClientExec.java:380)
...
```

  解决办法：先登录，然后将`Capabilities`禁用即可。

![image.png](https://img.hacpai.com/file/2019/11/image-d6b258ad.png)

#### 3、上传包出错

  运行`deploy`命令后提示以下信息：

```java
[ERROR] Failed to execute goal org.apache.maven.plugins:maven-deploy-plugin:2.8.2:deploy (default-deploy) 
on project web-app: Failed to deploy artifacts: Could not transfer artifact top.zyxwmj.yixing:web-app:war:1.0-repository 
from/to zyxwmj.top (http://localhost:8081/repository/maven-releases/): Failed to transfer file 
http://localhost:8081/repository/maven-releases/top/zyxwmj/yixing/web-app/1.0-repository/web-app-1.0-repository.war with status code 400 -> 
```

##### 原因一：仓库没有开启允许部署

  本地仓库的`Deployment policy`属性的默认值是`Disable redeploy`（禁止部署），需要把值改为`Allow redeploy`（运行部署）即可。

![image.png](https://img.hacpai.com/file/2019/11/image-7161cc91.png)

##### 原因二：配置文件错误

  配置文件的 id 必须和`settings.xml`的`server`的 id 对应，url 指定的必须是本地仓库的 url 而不是仓库组的 url。

```
<distributionManagement>
    <repository>
        <id>zyxwmj.top</id>
        <url>http://localhost:8081/repository/maven-releases/</url>
    </repository>
</distributionManagement>
```
