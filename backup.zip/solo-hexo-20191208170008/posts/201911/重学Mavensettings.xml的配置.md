title: 重学Maven—— settings.xml 的配置
date: '2019-11-06 13:29:03'
updated: '2019-11-06 17:42:34'
tags: [JavaWeb, Maven]
permalink: /articles/2019/11/06/1573018143484.html
---
![](https://img.hacpai.com/bing/20190811.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、settings.xml 的作用

  settings.xml 是 Maven 参数的配置文件，它用于配置本地仓库、远程仓库和联网使用的代理等信息。

### 二、settings.xml 的位置

settings.xml 文件可能存在两个位置：

* Maven 安装：$ {maven.home} /conf/settings.xml
* 用户的安装：$ {user.home} /.m2 / settings.xml

  前一个 settings.xml 也称为全局设置，后一个 settings.xml 称为用户设置。如果两个文件都存在，则它们的内容将合并，其中用户特定的 settings.xml 是主要文件。

### 三、settings.xml 中元素详解

#### 1、所有顶级元素

```
<settings xmlns="http://maven.apache.org/SETTINGS/1.0.0" 
	  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	  xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.0.0https://maven.apache.org/xsd/settings-1.0.0.xsd">
  <localRepository/>
  <interactiveMode/>
  <offline/>
  <pluginGroups/>
  <servers/>
  <mirrors/>
  <proxies/>
  <profiles/>
  <activeProfiles/>
</settings>
```

#### 2、LocalRepository

  LocalRepository 用于设置本地仓库的路径，默认`~/.m2/repository`。

```xml
<localRepository> F:\develop\apache-maven-3.6.1\local </localRepository>
```

#### 3、InteractiveMode

  InteractiveMode 用于表示 maven 是否需要和用户交互以获得输入。如果 maven 需要和用户交互以获得输入，则设置成 true，反之则应为 false。默认为 true。

**假如我们使用 Maven 创建一个 Java Web 项目。**

##### 方法一：

  只需在 cmd 中输入：`mvn archetype:generate`，随后 Maven 将下载 Archetype 插件及其所有的依赖插件，这些插件其实都是 jar 包，它们存放在您的 Maven 本地仓库中。这时你会看到很多 Archetype（原型），即为项目模板。我们选择`maven-archetype-webapp`创建 Java Web 项目，接着 Maven 会等待你输入一些信息。这种方式称为 Interactive Mode（交互模式）。

##### 方法二：

  如果你觉得上面的交互过于繁琐，那么你可以使用一条命令完成操作。`mvn archetype:generate -DinteractiveMode=false -DarchetypeArtifactId=maven-archetype-webapp -DgroupId=com.smart -DartifactId=smart-demo -Dversion=1.0`。这种方式称为 Batch Mode（批处理模式）。

##### 方法三：

  我也可以使用 IDE 来快速创建 Maven 项目，这种操作非常简单。

#### 5、offline

  如果此构建系统应在离线模式下运行，则为 true，默认为 false。对于网络设置或安全原因而无法连接到远程存储库的构建服务器，此元素很有用。

#### 6、pluginGroups

  该元素包含一个`pluginGroup`元素列表，每个元素都包含一个`groupId`。使用插件时搜索列表，并且命令行中未提供 groupId。此列表自动包含`org.apache.maven.plugins`和`org.codehaus.mojo`。

```xml
<pluginGroups>
    <pluginGroup>org.eclipse.jetty</pluginGroup>
</pluginGroups>
```

  例如，给定上述设置，Maven 命令行可以以简写形式执行`org.eclipse.jetty:jetty-maven-plugin:run`：

```css
mvn jetty:run
```

#### 7、servers

  用于下载和部署的存储库由 POM 的`repositories`和`distributionManagement`元素定义。但是，某些设置（如用​​户名和密码）不应与 pom.xml 一起分发。此类信息应存在于`settings.xml`中的构建服务器上。

```xml
<servers>
    <server>
      <!--仓库的名称-->
      <id>server001</id>
      <!--username和password用于对此服务器进行身份验证-->
      <username>my_login</username>
      <password>my_password</password>
      <!--privateKey和passphrase表示私钥的路径（默认是`${user.home}/.ssh/id_dsa`）和密码。密码和密码元素将来可能会外部化，但是现在必须在`settings.xml`文件中设置纯文本。-->
      <privateKey>${user.home}/.ssh/id_dsa</privateKey>
      <passphrase>some_passphrase</passphrase>
      <!--filePermissions和directoryPermissions 在部署中创建存储库文件或目录时，这些是使用权限。每个文件的合法值是一个三位数，与* nix文件的权限相对应，例如664或775。-->
      <filePermissions>664</filePermissions>
      <directoryPermissions>775</directoryPermissions>
      <configuration></configuration>
    </server>
</servers>
```

**注意：** 如果使用私钥登录服务器，请确保省略<password>元素。否则，密钥将被忽略。

#### 8、mirrors

  mirrors 用于定义远程仓库的镜像，如果访问远程仓库的速度比较慢，我们可以选择一个速度比较快的镜像。也可以将特定存储库替换为你可以更好地控制的内部存储库。

```
<mirrors>
  <!-- 给定仓库的下载镜像-->
  <mirror>
    <!-- 该镜像的唯一标识符。id用来区分不同的mirror元素-->
    <id>planetmirror.com</id>
    <!-- 镜像名称 -->
    <name>PlanetMirror Australia</name>
    <!-- 该镜像的URL。构建系统会优先考虑使用该URL，而非使用默认的服务器URL-->
    <url>http://downloads.planetmirror.com/pub/maven2</url>
    <!-- 被镜像的服务器的id。例如，如果我们要设置了一个Maven中央仓库（http://repo.maven.apache.org/maven2/）的镜像，就需要将该元素设置成central。 -->
    <mirrorOf>central</mirrorOf>
  </mirror>
</mirrors>
```

**mirrorOf 属性详解**

  当属性值为：`center`表示当前镜像为远程中央仓库的镜像。请注意，给定存储库最多可以有一个镜像。你不可以将单个存储库映射到完全相同`<mirrorOf>`值的一组镜像，Maven 不会汇总镜像，而只是选择第一个匹配项。你可以通过使 Maven 镜像将所有存储库请求来强制其使用单个存储库。存储库必须包含所有所需的工件，或者能够将请求代理到其他存储库。则将`<mirrorOf>`的值设置为`*`。

从 Maven 2.0.9 开始的语法：

* `*` = 一切
* `external:*` = 一切不在本地主机上，也不基于文件。
* `repo,repo1` =repo 或 repo1
* `*,!repo1` = 除了 repo1 以外的所有内容

#### 9、proxies

  如果你访问不了某一个仓库，可以使用代理，用的不多。

```xml
<proxies>
   <proxy>
      <!-- 此代理的唯一标识符。这用于区分代理元素-->
      <id>myproxy</id>
      <!-- 如果此代理处于活动状态，则为true。这对于声明一组代理很有用，但是一次只能激活一个代理-->
      <active>true</active>
      <!-- 代理的protocol：// host：port，分为独立的元素-->
      <protocol>http</protocol>
      <host>proxy.somewhere.com</host>
      <port>8080</port>
      <!-- 表示验证此代理服务器所需的登录名和密码-->
      <username>proxyuser</username>
      <password>somepassword</password>
      <!-- 这是不应代理的主机列表。列表的定界符是代理服务器的预期类型，示例是管道分隔符-逗号分隔也是常见的-->
      <nonProxyHosts>*.google.com|ibiblio.org</nonProxyHosts>
   </proxy>
</proxies>
```

#### 10、profiles

  `profiles`可以有多个`profile`，在`settings.xml`中的`profile`元素是`pom.xml`中`profile`元素的精简版本。它由`id`、`activation`、`properties`、`repositories`，`pluginRepositories`元素组成。它整个构建系统有关（这是`settings.xml`文件的作用），而不是单个项目对象模型设置。如果`profile`在`settings.xml`中被激活，则其值将覆盖 POM 或`profiles.xml`文件中任何等效的`id`配置。

##### ① activation 的作用

```xml
<profiles> 
    <profile> 
      <id> test </id> 
      <activation> 
        <!--profile默认是否激活的标识 -->
        <activeByDefault> false </activeByDefault> 
        <jdk> 1.5 </jdk> 
        <os> 
          <name> Windows XP </name> 
          <family> Windows </family> 
          <arch> x86 </arch> 
          <version> 5.1.2600 </version>
        </os> 
        <property> 
          <!--激活profile的属性的名称 -->
          <name> mavenVersion </name>
          <!--激活profile的属性的值 -->
          <value> 2.0.3 </value> 
        </property> 
        <file> 
          <!--如果指定的文件存在，则激活profile。 -->
          <exists> $ {basedir} /file2.properties </exists> 
          <!--如果指定的文件不存在，则激活profile。 -->
          <missing> $ {basedir} /file1.properties </missing> 
        </file > 
      </activation> 
      ... 
    </profile> 
</profiles> 
```

当满足所有指定条件时激活，但不是一定都需要：

* jdk：activation 在 jdk 元素中有一个内置的，以 Java 为中心的检查。如果测试是在与给定前缀匹配的 jdk 版本号下运行，则会激活此选项。在上面的例子中，`1.5.0_06`将匹配。从 Maven 2.1 开始也支持范围。有关支持的范围的更多详细信息，请参阅[maven-enforcer-plugin](https://links.jianshu.com/go?to=https%3A%2F%2Fmaven.apache.org%2Fenforcer%2Fenforcer-rules%2FversionRanges.html)。
* os：os 元素可以定义上面显示的一些操作系统特定属性。有关 OS 值的更多详细信息，请参阅[maven-enforcer-plugin](https://links.jianshu.com/go?to=https%3A%2F%2Fmaven.apache.org%2Fenforcer%2Fenforcer-rules%2FversionRanges.html)。
* property：如果 Maven 检测到相应`name=value`对的属性（可以在 POM 中取消引用`${name}`的值），则将激活该配置文件。
* file：给定的文件名可以通过文件的存在或缺少文件来激活配置文件。

  `activation`元素不是激活配置文件的唯一方式，`settings.xml`文件的`activeProfile`元素可能包含配置文件的 id。也可以在`-P`标志（例如`-P test`）之后通过命令行通过逗号分隔列表显式激活它们。

  要查看将在特定版本中激活的配置文件，请使用`maven-help-plugin`。

```css
mvn help:active-profiles
```

##### ② properties 的作用

  Maven 属性是值占位符，就像 Ant 中的属性一样。可以使用符号`${X}`在 POM 内的任何位置访问它们的值，其中`X`是属性。它们有五种不同的样式，都可以从 settings.xml 文件中访问：

1. `env.X`：使用“env.”前缀变量将返回 shell 的环境变量。例如，`${env.PATH}`返回 $path 环境变量（Windows 中是`％PATH％`）
2. `project.x`：POM 中的点（.）标记路径将包含相应元素的值。例如：`<project><version>1.0</version></project>`可通过`${project.version}`访问。
3. `settings.x`：`settings.xml`中的点（.）标记路径将包含相应元素的值。例如：`<settings><offline>false</offline></settings>`可通过`${settings.offline}`访问。
4. Java 系统属性：可通过`java.lang.System.getProperties()`访问的所有属性都可用作 POM 属性，例如`${java.home}`。
5. x：在`<properties />`元素或外部文件中设置的值，该值可以用作`${someVar}`。

```xml
<profiles>
   <profile>
      ...
      <properties>
        <user.install>${user.home}/our-project</user.install>
      </properties>
      ...
   </profile>
</profiles>
```

如果此配置文件被启用，则可以在 POM 中使用`${user.install}`访问该属性。

##### ③ repositories 的作用

  Repositories 是项目的远程集合，Maven 使用这些资源来填充构建系统的本地存储库。Maven 在此本地存储库中将其称为插件和依赖项。不同的远程存储库可能包含不同的项目，并且在启用的 profile 下，可以搜索它们以查找匹配的版本或快照工件。

```
<repositories>
  <!--包含需要连接到远程仓库的信息 -->
  <repository>
    <!--远程仓库唯一标识 -->
    <id>codehausSnapshots</id>
    <!--远程仓库名称 -->
    <name>Codehaus Snapshots</name>
    <!--如何处理远程仓库里发布版本的下载 -->
    <releases>
      <!--true或者false表示该仓库是否为下载某种类型构件（发布版，快照版）开启。 -->
      <enabled>false</enabled>
      <!--该元素指定更新发生的频率。Maven会比较本地POM和远程POM的时间戳。这里的选项是：always（一直），daily（默认，每日），interval：X（这里X是以分钟为单位的时间间隔），或者never（从不）。 -->
      <updatePolicy>always</updatePolicy>
      <!--当Maven验证构件校验文件失败时该怎么做-ignore（忽略），fail（失败），或者warn（警告）。 -->
      <checksumPolicy>warn</checksumPolicy>
    </releases>
    <!--如何处理远程仓库里快照版本的下载。有了releases和snapshots这两组配置，POM就可以在每个单独的仓库中，为每种类型的构件采取不同的策略。例如，可能有人会决定只为开发目的开启对快照版本下载的支持。参见repositories/repository/releases元素 -->
    <snapshots>
      <enabled>true</enabled>
      <updatePolicy>never</updatePolicy>
      <checksumPolicy>fail</checksumPolicy>
    </snapshots>
    <!--远程仓库URL，按protocol://hostname/path形式 -->
    <url>http://snapshots.maven.codehaus.org/maven2</url>
    <!--用于定位和排序构件的仓库布局类型-可以是default（默认）或者legacy（遗留）。Maven 2为其仓库提供了一个默认的布局；然而，Maven 1.x有一种不同的布局。我们可以使用该元素指定布局是default（默认）还是legacy（遗留）。 -->
    <layout>default</layout>
  </repository>
</repositories>
```

* releases, snapshots：这是针对每种工件，Release 或 snapshot 的策略。通过这两个集合，POM 可以在单个存储库中独立于另一个类型更改每种类型的策略。例如，对于开发目的的远程库，可以决定仅启用快照下载。
* enabled：是否为相应类型（`releases`或`snapshots`）启用此存储库，是`true`还是`false`。
* updatePolicy：此元素指定更新本地库频率。Maven 会将本地 POM 的时间戳（存储在存储库的 maven-metadata 文件中）与远程数据进行比较。选项包括：`always`，`daily`（默认），`interva:X`（其中 X 是以分钟为单位的整数）或`never`。
* checksumPolicy：当 Maven 将文件部署到存储库时，它还会部署相应的校验和文件。您可以选择`ignore`，`fail`或`warn`缺少或不正确的校验和。
* layout：在以上对存储库的描述中，提到它们都遵循相同的布局。这基本上是正确的。Maven 2 的存储库具有默认布局。但是，Maven 1.x 具有不同的布局。使用此元素可以指定默认还是传统。

##### ④ pluginRepositories 的作用

  存储库是两种主要类型的工件的所在地。第一个是用作其他工件的依赖项的工件，这些是驻留在 Central 中的大多数插件。另一种类型的工件是插件。Maven 插件本身就是一种特殊的工件。因此，插件存储库可能与其他存储库分离。在任何情况下，`pluginRepositories`元素块的结构类似于`repositories`元素。 `pluginRepository`元素指定 Maven 可以在哪里找到新插件的远程位置。

#### 11、ActiveProfiles

  activeProfiles 元素包含一组 activeProfile 元素，每个元素都有一个配置文件 ID 的值。无论任何环境设置如何，任何定义为 activeProfile 的配置文件 ID 都将处于活动状态。如果找不到匹配的配置文件，则不会发生任何事情。例如，如果 env-test 是 activeProfile，则 pom.xml（或具有相应 ID 的 profile.xml）中的配置文件将处于活动状态。如果未找到此类配置文件，则执行将照常继续。

```
<activeProfiles>
    <!-- 要激活的profile id -->
    <activeProfile> env-test </activeProfile>
</activeProfiles>
```

### 四、总结

#### 1、proxy、server、repository、mirror 的作用

* proxy 是服务器不能直接访问外网时需要设置的代理服务，不常用。
* server 是服务器要打包上传到私服时，设置私服的鉴权信息。
* repository 是服务器下载 jar 包的仓库地址。
* mirror 是用于替代仓库地址的镜像地址。

#### 2、mirror 和 repository 的特点

* 在 mirrorOf 与 repositoryId 相同的时候优先是使用 mirror 的地址。
* mirrorOf 等于 * 的时候覆盖所有 repository 配置。
* 存在多个 mirror 配置的时候 mirrorOf 等于 * 放到最后。
* 只配置 mirrorOf 为 central 的时候可以不用配置 repository。
