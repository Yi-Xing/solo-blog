title: '部署SSM项目 提示java.io.FileNotFoundException: class path resource [spring-mvc.xml]
  cannot be opened because it does not exist异常'
date: '2019-09-13 11:11:51'
updated: '2019-09-19 17:54:14'
tags: [坑, Tomcat]
permalink: /articles/2019/09/13/1568344311025.html
---
![](https://img.hacpai.com/bing/20190528.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 报错信息：
```
org.springframework.beans.factory.BeanDefinitionStoreException: 
IOException parsing XML document from class path resource [spring-mvc.xml]; 
nested exception is java.io.FileNotFoundException:
class path resource [spring-mvc.xml] cannot be opened because it does not exist
```
Tomcat提示spring-mvc.xml找不到。<br><br>  


### 原因：
&emsp;&emsp;Maven没有将resources包下的配置文件进行打包，导致运行的时候找不到配置文件。<br><br>


### 解决方法：
&emsp;&emsp;在Maven配置文件的\<build>标签中加入以下代码即可
```
<resources>
    <resource>
	<!-- 为了让java文件下的xml文件也能被读取-->
        <directory>src/main/java</directory>
        <includes>
            <include>**/*.xml</include>
        </includes>
        <filtering>true</filtering>
    </resource>
    <resource>
	<!-- 为了让resources中的文件也能被读取-->
        <directory>src/main/resources</directory>
        <includes>
            <include>**/*</include>
        </includes>
        <filtering>true</filtering>
    </resource>
</resources>
```

