title: Nginx的常用命令
date: '2019-09-15 09:38:03'
updated: '2019-09-20 09:53:42'
tags: [Nginx]
permalink: /articles/2019/09/15/1568511483324.html
---
![](https://img.hacpai.com/bing/20190509.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 1、查找 Nginx 的安装目录

```
whereis nginx  
```

![image.png](https://img.hacpai.com/file/2019/09/image-c89d94bb.png)

### 2、查看 Nginx 的版本信息
&emsp;&emsp;必须在Nginx的sbin目录下
#### 1）Nginx的版本信息
```
./nginx -v  
```
#### 2）Nginx的版本和配置信息  
```
./nginx -V  
```
![image.png](https://img.hacpai.com/file/2019/09/image-0d542256.png)

### 3、测试 Nginx 的配置文件是否合法
&emsp;&emsp;必须在Nginx的sbin目录下
```
./nginx -t
```

显示以下信息表示配置文件正常
![image.png](https://img.hacpai.com/file/2019/09/image-49fd4811.png)

### 4、Nginx 的启动

方法一：nginx 安装目录地址 -c nginx 配置文件地址
```
/usr/local/nginx/sbin/nginx -c /usr/local/nginx/conf/nginx.conf
```
方法二：必须在Nginx的sbin目录下执行
```
./nginx -c /usr/local/nginx/conf/nginx.conf
```

### 5、重启 Nginx

&emsp;&emsp;必须在Nginx的sbin目录下
```
./nginx -s reload
```

### 6、Nginx 的关闭
&emsp;&emsp;在 Nginx 的 sbin 目录下执行
#### 1）快速关闭
```
./nginx -s stop
```
#### 2）正常关闭
```
./nginx -s quit
```

