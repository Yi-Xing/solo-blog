title: 重学Maven——总结
date: '2019-11-01 11:44:40'
updated: '2019-11-08 10:24:51'
tags: [JavaWeb, Maven]
permalink: /articles/2019/11/01/1572579880188.html
---
![](https://img.hacpai.com/bing/20180811.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、Maven 的概念

  Maven 是一个项目管理工具，他包含了一个项目对象模型（POM:Project Object Model），一组标准的集合，一个项目声明周期,一个依赖管理系统和用来运行定义在生命周期阶段中插件目标的逻辑。

#### 1、管理模块之间的依赖：
  根据业务需求，系统会划分很多模块，这些模块彼此之间存在着依赖关系。比如系统管理模块依赖着文件上传模块，来实现用户头像上传的功能。maven 通过配置模块之间的 pom 依赖

#### 2、生命周期管理：
  在 Web 应用中，我们常要进行编译、打包、测试这些环节。在 maven 的世界里，将这些过程定义为生命周期。maven 将这些复杂的过程进行了封装，使用者只需要简单的用鼠标点几下就可以完成项目的构建工作

#### 3、强大的插件：
  举一个很常用的插件 tomcat7-maven-plugin，在以前，我们运行项目的方式是，将 Web 应用打包成 war-&gt; 手动拷贝到 Tomcat 的 webapp 目录下-&gt; 启动 Tomcat。现在有了 Maven 以上过程我们只需要点击一下鼠标即可完成。是不是很方便？

#### 4、仓库式管理：
  曾经为了找一个 jar 包费劲周折，曾经因为 jar 包冲突、版本产生莫名其妙的问题困扰我们好久。Maven 提供的[公用仓库](http://mvnrepository.com)，只要输入 jar 包的坐标即可查找到想要的资源，将模块的坐标加入到自己的 pom 中就可以快乐的使用了，真的觉得很方便。同时由于依赖的概念，与其相关的 jar 包也会引入到项目环境中，并且不会产生版本的问题

### 二、Maven 的仓库

  Maven 的仓库分为三类：本地仓库、远程仓库（私服）、中央仓库。
  仓库之间的关系：当我们启动一个 Maven 工程的时候，Maven 工程会通过 pom 文件中的 jar 包的坐标去本地仓库找对应的 jar 包。默认情况下，如果本地仓库没有对应的 jar 包，会先从私服下载，如果私服没有，可以从中央仓库下载也可以本地上传。

### 三、Maven 的三个标准的生命周期

  先配置环境变量，然后执行 mvn -version，查看 maven 是否安装成功，maven 命令格式：`maven xxx`。Maven 自身集成了 Tomcat 插件，通过 tomcat:run 命令运行。

#### 1、clean：项目清理的处理

  我们常用的命令是`mvn clean`来清楚编译生成的 target 文件。执行`mvn clean`命令，前面的命令也会执行，也就是说`mvn pre-clean`也会执行。

|生命周期阶段|描述|
|---|---|
|pre-clean|执行一些需要在 clean 之前完成的工作。|
|clean|移除所有上一次构建生成的 target 文件。|
|post-clean|执行一些需要在 clean 之后立刻完成的工作。|

#### 2、default(或 build)：项目部署的处理

  每一个构建项目的命令都对应了 Maven 底层一个插件。

##### ① 常见生命周期：

|命令|作用|
|---|---|
|compile|编译源码生成 target 文件|
|test|编译源码和测试代码并生成 target 文件|
|package|编译源码和测试代码并生成 target 文件并进行打包|
|install|编译源码和测试代码并生成 target 文件并进行打包，然后保存到本地仓库|
|deploy|前面的都执行，然后发布到远程仓库上|

##### ② 详细生命周期：

|生命周期阶段|描述|
|---|---|
|validate|检查工程配置是否正确，完成构建过程的所有必要信息是否能够获取到。|
|initialize|初始化构建状态，例如设置属性。|
|generate-sources|生成编译阶段需要包含的任何源码文件。|
|process-sources|处理源代码，例如，过滤任何值（filter any value）。|
|generate-resources|生成工程包中需要包含的资源文件。|
|process-resources|拷贝和处理资源文件到目的目录中，为打包阶段做准备。|
|compile|编译工程源码。|
|process-classes|处理编译生成的文件，例如 Java Class 字节码的加强和优化。|
|generate-test-sources|生成编译阶段需要包含的任何测试源代码。|
|process-test-sources|处理测试源代码，例如，过滤任何值（filter any values)。|
|test-compile|编译测试源代码到测试目的目录。|
|process-test-classes|处理测试代码文件编译后生成的文件。|
|test|使用适当的单元测试框架（例如 JUnit）运行测试。|
|prepare-package|在真正打包之前，为准备打包执行任何必要的操作。|
|package|获取编译后的代码，并按照可发布的格式进行打包，例如 JAR、WAR 或者 EAR 文件。|
|pre-integration-test|在集成测试执行之前，执行所需的操作。例如，设置所需的环境变量。|
|integration-test|处理和部署必须的工程包到集成测试能够运行的环境中。|
|post-integration-test|在集成测试被执行后执行必要的操作。例如，清理环境。|
|verify|运行检查操作来验证工程包是有效的，并满足质量要求。|
|install|安装工程包到本地仓库中，该仓库可以作为本地其他工程的依赖。|
|deploy|拷贝最终的工程包到远程仓库中，以共享给其他开发人员和工程。|

#### 2、site：站点生命周期

  site 一般用来创建新的报告文档、部署站点等，这里经常用到的是 site 阶段和 site-deploy 阶段，用以生成和发布 Maven 站点。

|生命周期|描述|
|---|---|
|pre-site|执行一些需要在生成站点文档之前完成的工作|
|site|生成项目的站点文档|
|post-site|执行一些需要在生成站点文档之后完成的工作，并且为部署做准备|
|site-deploy|将生成的站点文档部署到特定的服务器上|

### 三、ideal 使用 Maven 构建 Web 项目

  使用指定模板创建 Web 项目（需要连网），然后 Next 按自己的需求进行输入。
![image.png](https://img.hacpai.com/file/2019/11/image-4b8a5ace.png)
![image.png](https://img.hacpai.com/file/2019/11/image-b4a12a82.png)
  选中自己的 Maven，然后点击 Next，接着耐心等待，第一次比较慢。
![image.png](https://img.hacpai.com/file/2019/11/image-47931c1f.png)

### 四、Maven的配置文件
&emsp;&emsp;由于关于配置文件的信息比较多，所以专门总结了一下：
* settings.xml 文件的配置[（点我跳转）](http://zyxwmj.top/articles/2019/11/06/1573018143484.html)。
* pom.xml 文件的配置[（点我跳转）](http://zyxwmj.top/articles/2019/11/02/1572665261880.html)。

### 五、Jar 包冲突和解决

  Maven 工程要导入 jar 包，就必须要考虑解决 jar 包冲突。

#### 1、Maven 导入 jar 包的概念：

  直接依赖：项目中直接导入的 jar 包，就是该项目的直接依赖。
  传递依赖：项目中没有直接导入的 jar 包，可以通过项目直接依赖 jar 包传递到项目中。

#### 2、Maven 工程父子依赖关系:

  凡是依赖别的项目后，拿到别的项目的依赖包，都属于传递依赖。比如：当前 A 项目，被 B 项目依赖。那么我们 A 项目中所有 jar 包都会传递到 B 项目中。B 项目开发者，如果再在 B 项目中导入一套 Spring 框架的 jar 包，对于 B 项目就是直接依赖。那么直接依赖的 jar 包就会把我们 A 项目传递过去的 jar 包覆盖。为了防止以上情况的出现。我们可以把 A 项目中主要 jar 包的坐标锁住，那么其他依赖该项目的项目中，即便有同名的 jar 包直接依赖，也无法覆盖。

#### 3、解决 jar 包冲突的方式一：

  第一声明优先原则：哪个 jar 包的坐标在文件中的位置靠上，这个 jar 包就是先声明的。先声明的 jar 包坐标下的依赖包，可以优先进入项目中。

#### 4、解决 jar 冲突的方式二：

  路径近者优先原则：直接依赖路径比传递依赖路径近，那么最终项目进入的 jar 包会是路径近的直接依赖。

#### 5、解决 jar 冲突的方式三：

  直接排除法：当我们要排除某个 jar 包下载依赖，在配置 exclusions 标签的时候，内部可以不写版本号。

### 六、创建 Maven 多模块项目

#### 1、模块级开发的好处

  ① 多模块的划分可以降低代码之间的耦合性（从类级别的耦合提升到 jar 包级别的耦合）。
  ② 模块还规范了代码边界的划分，开发者很容易通过模块确定自己所负责的内容。
  ③ 工程和模块：工程不等于完整的项目，模块也不等于完整的项目，一个完整的项目看的是代码，代码完整就可以说这是一个完整的项目，和此项目是工程和模块没有关系。

#### 2、项目结构

  我创建一个 MavenDemo 主工程，里面包含两个模块（Module）：
    ① web-app 是应用层，用于界面展示，依赖于 web-service 模块。
    ② web-service 层是服务层，用于给 app 层提供服务。

#### 3、构建项目

① 创建主工程，新建一个空白标准 maven project（不要选择 Create from archetype 选项）。

![image.png](https://img.hacpai.com/file/2019/11/image-f8d6b4a2.png)

② 填写项目坐标。

![image.png](https://img.hacpai.com/file/2019/11/image-27064368.png)

③ 标准的 maven 项目创建完成。

![image.png](https://img.hacpai.com/file/2019/11/image-c2ff0fed.png)

④ 添加 web-app 模块。

![image.png](https://img.hacpai.com/file/2019/11/image-ad58ca2f.png)

⑤ 将 web-app 模块创建成 Web 模板。

![image.png](https://img.hacpai.com/file/2019/11/image-55d24a03.png)

⑥ 填写项目坐标。

![image.png](https://img.hacpai.com/file/2019/11/image-6924b0b1.png)

⑦ 选择自己的 Maven 地址。

![image.png](https://img.hacpai.com/file/2019/11/image-9ebe099c.png)

⑧ 确定项目名。

![image.png](https://img.hacpai.com/file/2019/11/image-78c3b135.png)

⑨ 按照以上步骤再创建 web-service 模块，目录结构如下：

![image.png](https://img.hacpai.com/file/2019/11/image-40e394e0.png)

#### 4、模块间相互引用

  如果 web-app 模块想调用 web-service 模块中的类，则需要在 web-app 模块的 pom 文件中加上如下代码即可：

```
    <dependencies>
        <dependency>
            <groupId>top.zyxwmj.yixing</groupId>
            <artifactId>MavenDemo</artifactId>
            <version>${project.version}</version>
        </dependency>
    </dependencies>
```

### 七、使用 Nexus 搭建私服并上传下载 Jar 包

  内容比较多，专门总结了一下[（点我跳转）](http://zyxwmj.top/articles/2019/11/04/1572866911213.html)。
