title: MySQL中数据的添加、更新、删除
date: '2019-10-09 22:44:34'
updated: '2019-10-15 17:13:34'
tags: [MySQL]
permalink: /articles/2019/10/09/1570632274905.html
---
![](https://img.hacpai.com/bing/20190712.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 
### 一、添加数据

#### 1、语法一：

```
insert into 表名(字段列表) values (值列表),(值列表)...;
```

  例子：

```
insert into curriculum(id,student_id,curriculum_name)  
values(9, 1, 'Java');  
```

#### 2、语法二：

  如果省略字段列表，则所有字段都必须设置值，且顺序不能有误。

```
insert into 表名 values(值列表),(值列表)...;
```

  例子：

```
insert into curriculum values(8, 1, 'Java');
```

### 二、更新数据

#### 1、单表更新语法

```
update 表名 
set 列=新值,列=新值... 
where 筛选条件;
```

  例如：

```
update curriculum 
set student_id=2,curriculum_name='python'
where id=9;
```

#### 2、多表更新语法

```
update 表1 
inner|left|right join 表2
on 连接条件
set 列=新值...
where 筛选条件;
```

  例如：

```
update student a
inner join curriculum b
on a.id=b.student_id
set a.class="四班",b.curriculum_name="C"
where b.curriculum_name="Java";
```

### 三、删除数据

#### 语法：

```
delete from 表名 where 筛选条件;
```

#### 例子：

```
delete from curriculum where id=9;
```

