title: Java中的内部类
date: '2019-10-24 22:20:12'
updated: '2019-10-30 08:48:28'
tags: [JavaSE]
permalink: /articles/2019/10/24/1571926812469.html
---
![](https://img.hacpai.com/bing/20180125.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、什么是内部类？

  Java 中运行将一个类定义在另一个类中，里面的称为内部类，内部类分为四种：成员内部类、静态内部类、局部内部类、匿名内部类。

```
/**
 * 外部类
 */
public class Outer {
    /**
     * 内部类
     */
    class Inner {
    }
}
```

### 二、为什么要用内部类？

  因为 Java 不支持多继承，当我们想继承多个类或者实现多个抽象类的时候，不得不借助于内部类来继承多个类。内部类都能独立地继承一个类或实现接口，所以无论外围类是否已经继承了某个接口的实现，对于内部类都没有影响。

### 三、内部类的应用

#### 1.成员内部类

  成员内部类是最普通的内部类，它的定义为位于另一个类的内部。需要注意的是， 当成员内部类拥有和外部类同名的成员变量或这方法时， 默认情况下访问的是内部类的成员， 如要访问外部类的同名成员， 需要使用以下形式：

```
外部类.this.成员变量  
外部类.this.成员方法
```

  内部类是依附外部类而存在的， 也就是说要创建成员内部类的对象，前提是创建一个外部类的对象，创建成员内部类的方式如下：

```
new 外部类().new 内部类();
```

  例如：

```
class Outer {
    private String domainName = "zyxwmj.top";
    static String name = "Yi-Xing";

    public void getValue() {
        // 内部类的private成员变量
        System.out.println("内部类的domainName：" + new Inner().domainName);
    }

    class Inner {
        private String domainName = "emmm";
        // static String name="Yi-Xing"; 不能定义静态方法和静态成员变量
        public void getValue() {
            System.out.println("内部类的domainName：" + domainName);
            // 外部类的private成员变量
            System.out.println("外部类的domainName：" + Outer.this.domainName);
            // 外部类的静态成员变量
            System.out.println("外部类的name：" + name);
        }
    }
}

public class Test {
    public static void main(String[] args) {
        Outer outer = new Outer();
        outer.getValue();
        Outer.Inner inner = outer.new Inner();
        inner.getValue();
    }
}
```

#### 2.匿名内部类

  匿名内部类应该是我们平常使用最多的了，可以减少代码量。
  语法：

```
[类名 变量名=]new 接口或父类名{

}[.方法名()];
```

  例如：如果在 Outer 类中创建继承 Outer 类的匿名内部类，则会抛出`java.lang.StackOverflowError`异常，堆栈溢出。

```
class Outer {
    private Test inner = new Test() {
        @Override
        public void value() {
            System.out.println("我的名字是：Yi-Xing");
        }
    };

    public void value() {
        System.out.println("我的域名是：zyxwmj.top");
        inner.value();
        new Test() {
            @Override
            public void value() {
                System.out.println("我的年龄是：18岁");
            }
        }.value();
    }
}

public class Test {
    public void value() {
    }

    public static void main(String[] args) {
        Outer outer = new Outer();
        outer.value();
    }
}
```

#### 3.静态内部类

  静态内部类也是定义在另一个类里面的类，只不过在类前加上了 static。静态内部类是不需要依赖于外部类的，与静态成员变量类似。
  例如：

```
class Outer {
    String domainName = "zyxwmj.top";
    static String name = "Yi-Xing";

    public static void getValue() {
        // 内部类的private成员变量
        System.out.println("内部类的domainName：" + new Inner().domainName);
        // 内部类的static成员变量
        System.out.println("内部类的name：" + Inner.name);
    }

    static class Inner {
        private String domainName = "emmm";
        static String name = "Yi-Xing";
        // static String name="Yi-Xing"; 不能定义静态方法和静态成员变量
        public void getValue() {
            System.out.println("内部类的domainName：" + domainName);
            // 不能访问外部类的非static的成员变量
            // System.out.println("外部类的domainName：" + Outer.this.domainName);
            // 外部类的静态成员变量
            System.out.println("外部类的name：" + Outer.name);
        }
    }
}

public class Test {
    public static void main(String[] args) {
        Outer.getValue();
        Outer.Inner inner = new Outer.Inner();
        inner.getValue();
    }
}
```

#### 4.局部内部类

  局部内部类是定义在一个方法或作用域中的类，它的访问权限仅限于方法内或作用域内。
  我们是无法在外部去创建局部内部类的实例对象的，因为局部内部类是定义在方法中的，而方法是需要所在类的对象去调用。
  局部内部类如果要去访问局部变量，那么局部变量必须声明为 final 类型。
  局部内部类就像是方法里面的一个局部变量一样，是不能有 public、protected、private 以及 static 修饰符的。
  例如：

```
class Outer {
    private String domainName = "zyxwmj.top";
    static String name = "Yi-Xing";

    public void getInner() {
        // 如果想让局部内部类访问局部变量必须用final声明
        final String value="我是局部变量";

        class Inner {
            private String domainName = "emmm";
            // static String name="Yi-Xing"; 不能定义静态方法和静态成员变量
            public void getValue() {
                System.out.println("内部类的domainName：" + domainName);
                // 外部类的private成员变量
                System.out.println("外部类的domainName：" + Outer.this.domainName);
                // 外部类的静态成员变量
                System.out.println("外部类的name：" + name);
                System.out.println("局部变量的value：" + value);
            }
        }
        Inner inner=new Inner();
        inner.getValue();
    }
}

public class Test {
    public static void main(String[] args) {
        Outer outer = new Outer();
        outer.getInner();
    }
}
```
