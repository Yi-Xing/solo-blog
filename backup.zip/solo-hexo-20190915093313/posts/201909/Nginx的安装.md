title: Nginx的安装
date: '2019-09-14 21:32:25'
updated: '2019-09-14 21:32:25'
tags: [Nginx]
permalink: /articles/2019/09/14/1568467945137.html
---
![](https://img.hacpai.com/bing/20181211.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

###  1、在安装Nginx之前先安装nginx的依赖
```
yum -y install make zlib zlib-devel gcc-c++ libtool  openssl openssl-devel
```


### 2、安装 PCRE
```
# 下载 PCRE 安装包
wget http://downloads.sourceforge.net/project/pcre/pcre/8.35/pcre-8.35.tar.gz

# 解压安装包
tar zxvf pcre-8.35.tar.gz

# 进入安装包目录
cd pcre-8.35

# 安装  
./configure  
make && make install

# 查看版本
pcre-config --version

```
显示版本号表示安装成功
![image.png](https://img.hacpai.com/file/2019/09/image-9f940751.png)

### 3、 安装 Nginx
[Nginx的下载官网](https://nginx.org/en/download.html)
```
# 下载 Nginx安装包
wget http://nginx.org/download/nginx-1.6.2.tar.gz

# 解压安装包
tar zxvf nginx-1.6.2.tar.gz

#进入安装包目录
cd nginx-1.6.2

# 编译安装 
./configure --prefix=/usr/local/nginx --with-http_stub_status_module --with-http_ssl_module --with-pcre=/usr/develop/pcre-8.35
make
make install

# 查看版本
/usr/local/nginx/sbin/nginx -v
```
显示版本号表示安装成功
![image.png](https://img.hacpai.com/file/2019/09/image-5459ceb4.png)




