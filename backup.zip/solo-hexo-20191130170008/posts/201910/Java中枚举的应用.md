title: Java中枚举的应用
date: '2019-10-24 10:18:45'
updated: '2019-10-30 11:40:14'
tags: [JavaSE]
permalink: /articles/2019/10/24/1571883525662.html
---
![](https://img.hacpai.com/bing/20190804.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、枚举的引入原因

#### 1、定义常量

  在枚举出现之前，如果想要表示一组特定的离散值，往往使用一些常量。

```
public static final int SEASON_SPRING = 1;
public static final int SEASON_SUMMER = 2;
public static final int SEASON_FALL = 3;
public static final int SEASON_WINTER = 4;
```

  使用常量会造成类型不安全。若一个方法中要求传入季节这个参数，用常量的话，形参就是 int 类型，开发者传入任意类型的 int 类型值就行，但是如果是枚举类型的话，就只能传入枚举类中包含的对象。

#### 2、手动实现枚举类

  在 Java5 以前需要手动实现枚举类，这样实现枚举类会造成代码臃肿，每个实例化对象也没有独立的方法。如果想实现每个实例对象拥有独立的方法，就必须给每个实例化对象一个唯一的标识，还需要一直维护 characteristic()方法。如：

```
class SeasonEnumeration {
    private final String seasonName;
    private final String seasonDesc;
    private final int id;
    public static final SeasonEnumeration SPRING = new SeasonEnumeration(1, "春天", "春暖花开");
    public static final SeasonEnumeration SUMMER = new SeasonEnumeration(2, "夏天", "夏日炎炎");
    public static final SeasonEnumeration AUTUMN = new SeasonEnumeration(3, "秋天", "秋高气爽");
    public static final SeasonEnumeration WINTER = new SeasonEnumeration(4, "冬天", "白雪皑皑");

    /**
     * 将构造方法私有不允许外部创建实例化对象
     */
    private SeasonEnumeration(int id, String seasonName, String seasonDesc) {
        this.id = id;
        this.seasonName = seasonName;
        this.seasonDesc = seasonDesc;
    }

    public String getSeasonName() {
        return seasonName;
    }

    public String getSeasonDesc() {
        return seasonDesc;
    }

    @Override
    public String toString() {
        return "seasonName='" + seasonName + '\'' + ", seasonDesc='" + seasonDesc + '\'';
    }

    public void characteristic() {
        switch (id) {
            case 1:
                System.out.println("晒太阳");
                break;
            case 2:
                System.out.println("吃雪糕");
                break;
            case 3:
                System.out.println("收粮食");
                break;
            case 4:
                System.out.println("玩雪球");
                break;
            default:
        }
    }
}

public class Test {
    public static void main(String[] args) {
        System.out.println(SeasonEnumeration.SPRING);
        SeasonEnumeration.SPRING.characteristic();
        System.out.println(SeasonEnumeration.SUMMER);
        SeasonEnumeration.SUMMER.characteristic();
        System.out.println(SeasonEnumeration.AUTUMN);
        SeasonEnumeration.AUTUMN.characteristic();
        System.out.println(SeasonEnumeration.WINTER);
        SeasonEnumeration.WINTER.characteristic();
    }
}
```

### 二、枚举类的定义

  语法：

```
public  enum 枚举类名{
	枚举项0,枚举项1,枚举项2,枚举项3..;
}
```

**注意事项：**
  ① 所有枚举类都是 Enum 的子类。
  ② 枚举项必须放在第一行，自动添加 public static final 修饰，枚举项就是该枚举类的实例化对象。如果枚举项后面没有东西分号可以省略（建议不要省略）。
  ③ 枚举类也可以有构造方法，但是都自动被 private 修饰。
  ④ 枚举类可以写抽象方法，但是枚举项必须重写。
  ⑤ 枚举项如果调用无参数构造方法，无需加括号。
  ⑥ 枚举类不可以被继承也不可以继承其他类，因为所有枚举类都继承 java.lang.Enum，Java 不支持多继承，但可以实现接口。

### 三、枚举类的实例

  使用枚举类不仅可以减少代码量，而且还可以在枚举类中定义抽象方法，每个枚举项进行不同的重写。

```
enum SeasonEnumeration {
    SPRING("春天", "春暖花开") {
        @Override
        public void characteristic() {
            System.out.println("晒太阳");
        }
    },
    SUMMER("夏天", "夏日炎炎") {
        @Override
        public void characteristic() {
            System.out.println("吃雪糕");
        }
    },
    AUTUMN("秋天", "秋高气爽") {
        @Override
        public void characteristic() {
            System.out.println("收粮食");
        }
    },
    WINTER("冬天", "白雪皑皑") {
        @Override
        public void characteristic() {
            System.out.println("玩雪球");
        }
    };
    private final String seasonName;
    private final String seasonDesc;

    SeasonEnumeration(String seasonName, String seasonDesc) {
        this.seasonName = seasonName;
        this.seasonDesc = seasonDesc;
    }

    @Override
    public String toString() {
        return "seasonName='" + seasonName + '\'' + ", seasonDesc='" + seasonDesc + '\'';
    }

    public String getSeasonName() {
        return seasonName;
    }

    public String getSeasonDesc() {
        return seasonDesc;
    }

    public abstract void characteristic();
}
```

### 四、枚举类的常用方法

  ① enumType 传入枚举类的 class，name 传入枚举项的名字，返回枚举项的实例对象，没有则抛出`IllegalArgumentException`异常。

```
public static <T extends Enum<T>> T valueOf(Class<T> enumType, String name)
```

  ② 隐藏方法，返回该枚举类的所有枚举项。

```
public static <T extends Enum<T>>[] values()
```

  ③ 返回此枚举项的名称。

```
public final String name()
```

  ④ 返回此枚举项在枚举类中的下标（从 0 开始）。

```
public final int ordinal()
```

  ⑤ 返回此枚举项的 Class 对象。

```
public final Class<E> getDeclaringClass() 
```

  ⑥ 比较此枚举与指定对象的顺序。

```
public final int compareTo(E o)
```
### [五、使用枚举类代替魔法值](http://zyxwmj.top/articles/2019/10/24/1571883918035.html)
