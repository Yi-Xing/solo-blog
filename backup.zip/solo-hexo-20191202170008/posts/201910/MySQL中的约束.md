title: MySQL中的约束
date: '2019-10-11 11:43:30'
updated: '2019-10-16 09:01:00'
tags: [MySQL]
permalink: /articles/2019/10/11/1570765410925.html
---
![](https://img.hacpai.com/bing/20190422.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、含义

  约束是一种限制，用于限制表中的数据，为了保证表中的数据的准确性和可靠性。

### 二、分类

#### 1、约束的作用

  ① not null：非空，用于保证该字段的值不能为空。
  ② default：默认值，为指定字段设置默认值。
  ③ primary key：主键，用于保证该字段的值具有唯一性，并且非空。
  ④ unique：唯一，用于保证该字段的值具有唯一性。
  ⑤ auto_increment：自增，可以不用手动的插入值，系统提供默认的序列值。
  ⑥ foreign key：外键，用于限制两个表的关系，用于保证该字段的值必须来自于主表的关联列的值。在从表中添加外键约束，用于引用主表中某列的值。
  ⑦ check：检查约束，在 MySQL 8.0.16 版本之前的 check 约束能被解析，但是被忽略掉了，就是写了也没用。

#### 2、添加约束的时机：

  ①创建表时。
  ②修改表时。

#### 3、约束的添加：

  ①列级约束：上面的约束语法上都支持，但外键约束没有实际效果。
  ②表级约束：除了非空、默认，自动增长，其他的都支持。

### 三、实例

#### 1、查看表的结构，包含约束名  
~~~  
show create table 表名;  
~~~

#### 2、添加列级约束
##### 1）创建表时添加约束

  语法：直接在字段的类型后面追加约束类型即可。

```
create table 表名( 
	列名 数据类型 [约束], 
	 ... 
	列名 数据类型 [约束] 
);
```

  例子：

```
create table zyx(
	id int primary key auto_increment,-- 主键且自增长
	student_id varchar(10) unique,-- 唯一
	name varchar(5) not null,-- 非空
	gender char(1) check(gender='男' or gender='女'), -- 检查
	age int default(18) -- 默认值
);
```
##### 2）修改表时添加约束
  语法：
~~~
alter table 表名 modify column 字段名 字段类型 新约束;
~~~
  例子
~~~
alter table zyx modify column age int not null;
~~~
#### 3、添加表级约束
##### 1）创建表时添加约束

  语法：在各个字段的最下面。

```
create table 表名( 
	列名 数据类型 [约束], 
	 ... 
	列名 数据类型 [约束],
	-- 表级约束
	[constraint 约束名] 约束类型(字段名),
	...
	[constraint 约束名] 约束类型(字段名)
);
```

  例子：

```
create table zyx( 
	id int  auto_increment,-- 自增长
	student_id varchar(10),
	name varchar(5) not null,-- 非空
	gender char(1),
	age int default (18), -- 默认值
	-- 表级约束
	constraint aa  primary key(id),-- 主键
	unique(student_id),-- 唯一
	check(gender='男' or gender='女'), -- 检查
	foreign key(id) references zyx4(id) -- 外键
);
```
##### 2）修改表时添加约束
  语法：
~~~
alter table 表名 add [constraint 约束名] 约束类型(字段名) [外键的引用];
~~~
  例子：
~~~
alter table zyx1 add foreign key(id) references zyx2(id);-- 添加外键
~~~

#### 4、删除约束

##### 1）删除非空约束、默认约束、自增长约束
~~~
alter table 表名 modify column 字段名 字段类型;
~~~
##### 2）删除主键
~~~
alter table 表名 drop primary key;
~~~
##### 3）删除唯一约束
~~~
alter table 表名 drop index 唯一约束名;
~~~

##### 4）删除外键
~~~
alter table 表名 drop foreign key 外键约束名;
~~~

##### 5）删除约束
~~~
alter table 表名 drop check 字段的检查约束名;
~~~


### 四、补充
#### 1、多表之间的建表原则：  
##### 1）一对一：公民和身份证
&emsp;&emsp;建表原则：让两个表里的主键建立关系，主要用于拆表。
##### 2）一对多：商品和分类  
&emsp;&emsp;建表原则：在商品中添加外键指向分类的主键。
##### 3）多对多：学生和老师，学生和课程表
&emsp;&emsp;建表原则：建立一张中间表，将多对多的关系拆分成一对多的关系，中间表至少要有俩外键，分别指向其他两个表。
#### 2、主键和唯一约束的区别：
  ①都具有唯一性。
  ②主键不允许为 null，唯一允许。
  ③主键一个表只能设一个，唯一约束可以设置多个。
  ④都允许多字段结合，但不推荐使用。
#### 3、外键：
  ①要从从表设置外键关系。
  ②从表的外键列的类型和主表的关联列的类型要求一致或者兼容。
  ③主表的关联列必须是一个key（一般是主键或唯一）。
  ④插入数据时，先插入主表，再插入从表。删除数据时，先删除从表，在删除主表。
#### 4、自增长约束：
  ①自增长约束又叫标识列，标识列必须是一个key。
  ②一个表最多有一个标识列。
  ③标识列的类型只能是数值型。

