title: MySQL中的流程控制结构
date: '2019-10-14 11:05:18'
updated: '2019-10-15 16:24:26'
tags: [MySQL]
permalink: /articles/2019/10/14/1571022318180.html
---
![](https://img.hacpai.com/bing/20171227.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、流程控制结构分类

  1）顺序结构：程序从上往下依次执行。
  2）分支结构：程序从两条或多条路径中选着一条去执行。
  3）循环结构：程序在满足一定条件的基础上，重复执行一段代码。

### 二、分支结构

#### 1、if 函数

##### 1）语法

  如果逻辑表达式为 ture，返回表达式 1，否则返回表达式 2。

```
if(逻辑表达式,表达式1,表达式2);
```

##### 2）实例

```
select if(1>2,"1大于2","1小于2");
```

#### 2、case 结构

##### 1）语法：

  ①类似于 Java 中的 switch 语句，一般用于实现等值判断。

```
case 变量|表达式|字段
when 要判断的值1 then 返回的值1或语句1;
when 要判断的值2 then 返回的值2或语句2;
...
[else 返回的值n或语句n;]
end [case];
```

  ②类似于 Java 中的多重 if 语句，一般用于实现区间的判断。

```
case 
when 要判断的条件1 then 返回的值1或语句1;
when 要判断的条件2 then 返回的值2或语句2;
...
[else 返回的值n或语句n;]
end [case];
```

##### 2）特点：

  ①如果一个 then 后面为值或者语句其他 then 和 else 后面都必须为值或语句。
  ②如果 then 后面为值，则作为表达式使用，可以放在任何地方。then 和 else 后面都不需要使用分号（;）结尾，结束语句使用 end 而不是 end case。
  ③如果 then 后面为语句，则只能放在 begin end 语句中。 then 和 else 后面必须以分号（;）结尾，结束语句使用 end case 而不是 end。
  ④语法一是将 case 后面的值和 when 后面的值做比较，如果相等执行对应 then 后面值或语句，并结束判断。如果都不相等执行 else 后面的值或语句。
  ⑤语法二是判断每个 when 后面的条件是否成立，成立则执行对应 then 后面值或语句，并结束判断。如果都不成立执行 else 后面的值或语句。
  ⑥ else 可以省略，如果省略且所有条件都不满足，则返回 null。

##### 3）实例

  ①语法一作为表达式使用。

```
select case if(3>6,4,5)
when 4 then "对"
when 5 then "错"
else "异常"
end;
```

  ②语法二作为表达式使用。

```
select  case 
when 5<3 then "错"
when 5>2 then "对"
end;
```

  ③语法一作为语句使用。

```
-- 创建一个存储过程。
create procedure zyx(inout value varchar(20))
begin
	case value
	when "a" then set value="zyx";
	when "b" then set value="wmj";
	else set value=".top";
	end case;
end;
-- 创建一个用户变量并调用存储过程，打印结果。
set @value="a";
call zyx(@value);
select @value;
```

  ④语法二作为语句使用。

```
-- 创建一个存储过程。
create procedure zyx(out value varchar(20))
begin
	case
	when 3>4 then set value="3>4";
	when 3<4 then set value="3<4";
	else set value="3=4";
	end case;
end;
-- 创建一个用户变量并调用存储过程，打印结果。
set @value="";
call zyx(@value);
select @value;
```

#### 3、if 结构

##### 1）语法

  用于实现多重分支，只能放在 begin end 中。

```
if 条件 then 语句1;
elseif 条件2 then 语句2;
....
else 语句n;
end if;
```

##### 2）实例

```
-- 创建一个存储过程。
create procedure zyx(out value varchar(20))
begin
	if 3>4 then set value="3>4";
	elseif 3<4  then set value="3<4";
	else set value="3=4";
	end if;
end;
-- 创建一个用户变量并调用存储过程，打印结果。
set @value="";
call zyx(@value);
select @value;
```

### 三、循环结构

  循环结构都只能放在 begin end 语句中，标签用于结合循环控制语句使用。
#### 1、while

##### 1）语法

  特点先判断条件是否成立，然后执行语句，条件为false结束循环。

```
[标签:]while 循环条件 do
	循环体;
end while [标签];
```

##### 2）实例

```
create procedure zyx(in value int)
begin
	while value<6 do
		select value;
		set value=value+1;
	end while;
end;

set @value=3;
call zyx(@value);
```

#### 2、loop

##### 1）语法

  没有判断条件的死循环，只能使用循环控制结束循环。

```
[标签:]loop
	循环体;
end lopp [标签];
```

##### 2）实例

```
create procedure zyx(in value int)
begin
	zyx:loop
		-- leave是循环控制语句，用于结束当前循环体
		if value>6 then leave zyx;end if;
		select value;
		set value=value+1;
	end loop zyx;
end;

set @value=3;
call zyx(@value);
```

#### 3、repeat

##### 1）语法

  先执行语句后判断条件，条件为true结束循环。

```
[标签:]repeat
	循环体;
until 结束循环的条件
end repeat[标签];
```

##### 2）实例

```
create procedure zyx(in value int)
begin
	repeat
		select value;
		set value=value+1;
		until value>6
	end repeat;
end;

set @value=3;
call zyx(@value);
```

#### 4、循环控制
  循环控制语句需要和循环语句中的标签结合使用。
##### 1）iterate

  iterate 类似于 Java 中的 continue ，结束当前循环，继续下一次循环。
~~~
create procedure zyx(in value int)
begin
	zyx:while value<6 do
		set value=value+1;
		-- 当value等于4时，结束当前循环。
		if value=4 then iterate zyx;end if;
		select value;
	end while zyx;
end;

set @value=3;
call zyx(@value);
~~~
##### 2）leave

  leave 类似于 break，结束当前所在的循环结构。
~~~
create procedure zyx(in value int)
begin
	zyx:loop
		-- 当value等于6时，结束当前循环结构。
		if value>6 then leave zyx;end if;
		select value;
		set value=value+1;
	end loop zyx;
end;

set @value=3;
call zyx(@value);
~~~
