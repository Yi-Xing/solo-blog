title: 重学Maven——POM配置
date: '2019-11-02 11:27:41'
updated: '2019-11-03 17:38:41'
tags: [JavaWeb, Maven]
permalink: /articles/2019/11/02/1572665261880.html
---
![](https://img.hacpai.com/bing/20180209.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、什么是 POM

  POM 代表“项目对象模型”。它是 Maven 项目的配置文件以 XML 表示形式`pom.xml`。它包含所涉及的开发人员及其所扮演的角色，缺陷跟踪系统，组织和许可证，项目所在的 URL，项目的依存关系以及所涉及的所有其他小部分玩以赋予代码生命实际上，在 Maven 世界中，一个项目根本不需要包含任何代码，只需包含一个`pom.xml`。

### 二、POM 的简单概述

  这是 POM 项目元素正下方的元素列表。请注意，`modelVersion`其中包含 4.0.0。这是当前 Maven 2 和 3 唯一受支持的 POM 版本，并且始终是必需的。

```
<project xmlns = “ http://maven.apache.org/POM/4.0.0” 
  的xmlns：的xsi = “http://www.w3.org/2001/XMLSchema-instance”
  xsi：schemaLocation = “ http://maven.apache.org/POM/4.0.0
                      http://maven.apache.org/xsd/maven-4.0.0.xsd“ >
  <modelVersion> 4.0.0 </modelVersion>
 
  <！-基础知识->
  <groupId> ... </groupId>
  <artifactId> ... </artifactId>
  <version> ... </version>
  <packaging> ... </packaging>
  <dependencies> ... </dependencies>
  <parent> ... </parent>
  <dependencyManagement> ... </dependencyManagement>
  <modules> ... </modules>
  <properties> ... </properties>
 
  <！-更多项目信息->  
  <name> ... </name>  
  <description> ... </description>  
  <url> ... </url>  
  <inceptionYear> ... </inceptionYear>  
  <licenses> ... </licenses>  
  <organization> ... </organization>  
  <developers> ... </developers>  
  <contributors> ... </contributors>

  <！-构建设置->
  <build> ... </build>
  <reporting> ... </reporting>
 
  <！-环境设置->
  <issueManagement> ... </issueManagement>
  <ciManagement> ... </ciManagement>
  <mailingLists> ... </mailingLists>
  <scm> ... </scm>
  <prerequisites> ... </prerequisites>
  <repositories> ... </repositories>
  <pluginRepositories> ... </pluginRepositories>
  <distributionManagement> ... </distributionManagement>
  <profiles> ... </profiles>
</project>
```

### 三、基础配置

#### 1、Maven 坐标

`groupId:artifactId:version`是所有必填字段（不过，如果它们是从父级继承的，则无需显式定义）。
groupId：这在组织或项目中通常是唯一的。
artifactId：artifactId 通常是已知项目的名称。
version：版本号。

#### 2、打包

`packaging`用来确定，我们执行`mvn package`命令后，项目打成什么包。如果没有声明包装，则 Maven 会认为包装是默认包装：`jar`。当前的核心包装值是：`pom`，`jar`，`maven-plugin`，`ejb`，`war`，`ear`，`rar`。

#### 3、依赖列表

```
<!--一个 pom.xml 文件中只能存在一个这样的标签。用来管理依赖的总标签。-->
<dependencies>
    <!--包含在 dependencies 标签中，可以有无数个，每一个表示一个依赖。-->
    <dependency>
        <!--groupId,artifactId 和 version：依赖的基本坐标，对于任何一个依赖来说，基本坐标是最重要的，Maven 根据坐标才能找到需要的依赖-->
        <groupId>junit</groupId>
        <artifactId>junit</artifactId>
        <version>4.11</version>
        <!--依赖的范围，默认值是 compile。后面会进行详解。-->
        <scope>test</scope>
        <!--依赖的类型，对应于项目坐标定义的 packaging。大部分情况下，该元素不必声明，其默认值是 jar。-->
	<type>jar<type>
        <!--标记依赖是否可传递，true表示不传递，false即可传递-->
	<optional>false</optional>
        <!--用来包含多个排除依赖。-->
	<exclusions>
            <!--用来排除传递性依赖。-->
            <exclusion>
                <groupId>javax.servlet</groupId>
                <artifactId>servlet-api</artifactId>
            </exclusion>
	</exclusions>
    </dependency>
</dependencies>
```

① groupId,artifactId 和 version：来确定依赖的坐标，可以去[中央仓库查找](https://mvnrepository.com/)。

② scope：依赖的范围

|依赖范围|编译有效|测试有效|运行有效|例子|
|---|---|---|---|---|
|compile|√|√|√|spring-core|
|test|-|√|-|Junit|
|provided|√|√|-|servlet_api|
|runtime|-|√|√|JDBC 驱动|
|system|√|√|-|本地的，Maven 仓库之外的类库|

③ optional Dependencies（直接依赖）和 exclusions Dependencies（传递依赖）的作用
  假如现在有 A，B，C，3 个项目。C 依赖于 B，B 依赖于 A，那么 C 也依赖于 A。
  虽然项目 C 依赖项目 B，但项目 C 不是完全依赖项目 B 的时候，即项目 C 只用到了项目 B 的一部分功能，而正巧项目 B 这部分功能的实现，并不需要依赖于项目 A，这个时候，项目 C 就应该排除对项目 A 的依赖。

**方法一：**
  Optional Dependencies：&lt;optional&gt;标签表示该依赖是否可选，默认是false，即可以传递，true表示不可传递。从项目 B 入手，使项目 C 依赖项目 B 时，排除对项目 A 的依赖。项目 B 的配置如下：

```
<dependency>
      <groupId>A</groupId>
      <artifactId>zyxwmj.top-A</artifactId>
      <version>1.0</version>
      <optional>true</optional>
</dependency>
```

**方法二：**
  Exclusions Dependencies：用于将当前直接依赖的传递依赖排除掉，防止 jar 包冲突。如果项目 B 没有把项目 A 设置为可选依赖（Optional Dependencies），而项目 C 又想在依赖项目 B 的同时不依赖项目 A，项目 C 的配置如下：

```
<dependency>
      <groupId>B</groupId>
      <artifactId>zyxwmj.top-B</artifactId>
      <version>1.0</version>
      <exclusions>
        <exclusion> 
          <groupId>A</groupId>
          <artifactId>zyxwmj.top-A</artifactId>
        </exclusion>
      </exclusions> 
</dependency>
```

#### 3、锁定依赖版本 &lt;dependencyManagement&gt;

  在同一个 pom 文件下，如果 &lt;dependencies&gt; 和 &lt;dependencyManagement&gt; 中都对该 jar 做了依赖，以 &lt;dependencies&gt; 的为准，&lt;dependencyManagement&gt; 里只是声明依赖，并不实现引入。
  假如我们有 A、B 两个项目，A 和 B 项目都需要一个些 Jar 包，当这些 Jar 包的版本变化时修改起来又会很麻烦。解决办法是在创建一个项目，在该项目的 pom 文件中使用 &lt;dependencyManagemen&gt; 将 Jar 包管理起来，如果有哪个子项目要用，就依赖该项目。

```
<dependencyManagement>
    <dependencies>
        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-core</artifactId>
            <version>3.2.7</version>
        </dependency>
    </dependencies>
</dependencyManagement>
```

#### 4、继承依赖 &lt;parent&gt;

  Maven 项目之间不仅存在多模块的聚合关系，而且 Maven 项目之间还可以存在相互继承的关系。Maven 项目之间的继承关系通过 &lt;parent&gt; 表示，通过 &lt;parent&gt; 引用的项目 A，可以使用 A 项目中 &lt;dependency&gt; 中的依赖，但是不能调用 A 项目中自己定义的类和方法，C 项目中通过 &lt;dependency&gt; 依赖的 A,两者却都可以调用。
  假如我们有 A、B 两个项目，A 和 B 项目都需要一个些 Jar 包，当这些 Jar 包的版本变化时修改起来又会很麻烦。解决办法是创建一个 parent 项目，打包类型为 pom。parent 项目中不存放任何代码，只是管理多个项目之间公共的依赖。A、B 项目中只需要定义 &lt;parent&gt; 即可。

```
<parent>
    <groupId>zyxwmj.top</groupId>
    <artifactId>my-parent</artifactId>
    <version>2.0</version>
    <!--以当前工程文件为基准的父工程 pom.xml文件的相对路径（可以不配置）-->
    <relativePath>../my-parent</relativePath>
</parent>
```

#### 5、聚合模块 &lt;modules&gt;

  在父项目的 POM 文件中使用 &lt;modules&gt; 聚合模块，在不同的 pom 文件中，存在父子相互依赖关系的，父项目的 pom 中 &lt;dependencyManagement&gt; 中对该 jar 做了依赖，而子项目中 &lt;dependencies&gt; 又依赖了该 jar，如果子项目中没有指定 &lt;version&gt; 和 &lt;scope&gt;，则继承父项目中该 jar 的 &lt;version&gt; 和 &lt;scope&gt;。如果子项目中指定了 &lt;version&gt; 和 &lt;scope&gt;，以子项目的为准。

```
<modules>
  <module> A </module>
  <module> B </module>
  <module> C </module>
</modules>
```

#### 6、属性 &lt;Properties&gt;

  属性是了解 POM 基础知识的最后一个要素。Maven 属性是值占位符，如 Ant 中的属性。它们的值可以通过使用符号**${X}**在POM中的任何位置访问，其中X是属性。
通过<properties>元素用户可以自定义一个或多个Maven属性，然后在POM的其他地方使用${属性名}的方式引用该属性，这种做法的最大意义在于消除重复和统一管理。通过<properties>元素用户可以自定义一个或多个 Maven 属性，然后在 POM 的其他地方使用 ${属性名}的方式引用该属性，这种做法的最大意义在于消除重复和统一管理。Maven 总共有 6 类属性，内置属性、POM 属性、自定义属性、Settings 属性、Java 系统属性和环境变量属性；

##### ① 内置属性

  两个常用内置属性 ${basedir} 表示项目跟目录，即包含pom.xml文件的目录；${version} 表示项目版本

##### ② POM 属性

  用户可以使用该类属性引用 POM 文件中对应元素的值。如 ${project.artifactId}就对应了<project> <artifactId>元素的值，常用的 POM 属性包括：

```
* ${project.build.sourceDirectory}:项目的主源码目录，默认为 src/main/java/
* ${project.build.testSourceDirectory}:项目的测试源码目录，默认为 src/test/java/
* ${project.build.directory} ： 项目构建输出目录，默认为 target/
* ${project.outputDirectory} : 项目主代码编译输出目录，默认为 target/classes/
* ${project.testOutputDirectory}：项目测试主代码输出目录，默认为 target/testclasses/
* ${project.groupId}：项目的 groupId
* ${project.artifactId}：项目的 artifactId
* ${project.version}：项目的version,与${version} 等价
* ${project.build.finalName}：项目打包输出文件的名称，默认为${project.artifactId}-${project.version}
```

##### ③ 自定义属性

  随便写

##### ④ Settings 属性

  与 POM 属性同理，用户使用以 settings. 开头的属性引用 settings.xml 文件中的 XML 元素的值。

##### ⑤ Java 系统属性

  所有 Java 系统属性都可以用 Maven 属性引用，如 ${user.home}指向了用户目录。

##### ⑥ 环境变量属性

  所有环境变量属性都可以使用以 env. 开头的 Maven 属性引用，如 ${env.JAVA_HOME}指代了 JAVA_HOME 环境变量的的值。

###   目前只学到了这里），未完待续（[官网链接](http://maven.apache.org/pom.html#Properties)）。。。。

### 四、构建配置

### 五、项目信息配置

### 六、环境配置
