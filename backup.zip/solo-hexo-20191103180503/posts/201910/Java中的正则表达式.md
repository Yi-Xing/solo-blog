title: Java中的正则表达式
date: '2019-10-24 22:22:27'
updated: '2019-10-29 15:56:40'
tags: [JavaSE]
permalink: /articles/2019/10/24/1571926946969.html
---
![](https://img.hacpai.com/bing/20180115.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、[正则表达式的基本语法](http://zyxwmj.top/articles/2019/10/24/1571886568190.html)

### 二、String 类

#### 1、matches 方法——验证字符串

  判断字符串是否匹配正则表达式。

```
boolean matches(String 正则的规则)
```

  如：判断 str 字符是否满足 regex 规则（只能是有数字和字母组成）

```
public class Regular {
    public static void main(String[] args) {
        String str="123ax";
        String regex="[a-zA-z0-9]+";
        System.out.println(str.matches(regex));
    }
}
```

#### 2、split 方法——分割字符串

  按指定规则对字符串进行切割，切割符舍去。

```
String[] split(String 正则的规则)
```

  如：将字符串 str 按逗号（，）或者句号（。）分割。

```
public class Regular {
    public static void main(String[] args) {
        String str="小张，小明，小王。小兴";
        String regex="[，。]";
        System.out.println(Arrays.toString(str.split(regex)));
    }
}
```

  按指定规则对字符串进行切割（切割成指定的个数），切割符舍去。

```
String[] split(String 正则的规则,int 分割的个数)
```

  如：将字符串 str 按句号（。）或者乘号（*）分割，分割成 3 份。

```
public class Regular {
    public static void main(String[] args) {
        String str="小张*小明*小王。小兴*小梦。小姣*小易。小红";
        String regex="[。*]";
        System.out.println(Arrays.toString(str.split(regex,3)));
    }
}
```

#### 3、replaceXXX——替换字符串

  按指定规则替换字符串。

```
String replaceAll(String 正则的规则,String 替换的字符串)
```

  将字符串 str 中的逗号（，）和句号（。）替换成（-），替换所有满足条件的字符串

```
public class Regular {
    public static void main(String[] args) {
        String str="小张，小明，小王。小兴";
        String regex="[。，]";
        System.out.println(str.replaceAll(regex,"-"));
    }
}
```

  按指定规则替换字符串，只替换第一个。

```
String  replaceFirst(String 正则的规则,String 替换的字符串)
```

  将字符串 str 中的逗号（，）和句号（。）替换成（-），只替换第一个满足条件的字符串。

```
public class Regular {
    public static void main(String[] args) {
        String str="小张，小明，小王。小兴";
        String regex="[。，]";
        System.out.println(str.replaceFirst(regex,"-"));
    }
}
```

### 三、Pattern 类

  pattern 对象是一个正则表达式的编译表示。Pattern 类没有公共构造方法。要创建一个 Pattern 对象，你必须首先调用其公共静态编译方法，它返回一个 Pattern 对象。该方法接受一个正则表达式作为它的第一个参数。

#### 1、matches 方法——验证字符串

  判断字符串是否匹配正则表达式，和 String 的 matches 效果一样。

```
static boolean matches(String regex, CharSequence input) 
```

#### 2、compile 方法——创建实例化对象

  将给定的正则表达式编译成模式。

```
static Pattern compile(String regex) 
```

  用给定的标志将给定的正则表达式编译成一个模式。

```
static Pattern compile(String regex, int flags) 
```

  匹配模式表：

|名称|作用|
|---|---|
|CANON_EQ|启用规范等价|
|CASE_INSENSITIVE|启用不区分大小写的匹配|
|COMMENTS|模式中允许空白和注释|
|DOTALL|启用 dotall 模式|
|LITERAL|启用模式的字面值解析|
|MULTILINE|启用多行模式|
|UNICODE_CASE|启用 Unicode 感知的大小写折叠|
|UNICODE_CHARACTER_CLASS|启用 Unicode 版本的预定义字符类和 POSIX 字符类|
|UNIX_LINES|启用 Unix 行模式|

#### 3、查看 Pattern 类的成员变量

  返回此模式被编译的正则表达式。

```
String pattern() 
String toString() 
```

  返回此模式的匹配标志，即构造方法的 flags。

```
int flags() 
```

#### 4、split 方法——拆分字符串

  按指定规则对字符串进行切割，切割符舍去。

```
String[] split(CharSequence input) 
```

  按指定规则对字符串进行切割（切割成指定的个数），切割符舍去。

```
String[] split(CharSequence input, int limit) 
```

#### 5、quote 方法——生成正则表达式

  将指定字符串生成正则表达式。

```
static String quote(String s)
```

#### 6、matcher 方法——创建 Matcher 类

  给定一个要匹配的字符串，创建一个 Matcher 类。

```
Matcher matcher(CharSequence input) 
```

### 四、Matcher 类

  Matcher 对象是对输入字符串进行解释和匹配操作的引擎。与 Pattern 类一样，Matcher 也没有公共构造方法。你需要调用 Pattern 对象的 matcher 方法来获得一个 Matcher 对象。

#### 1、pattern 方法——返回匹配模式

  返回创建它的 Pattern 对象。

```
Pattern pattern() 
```

#### 2、匹配字符串

##### ①匹配整个字符串

  判断整个字符串是否匹配正则表达式。

```
boolean matches() 
```

##### ②匹配开头字符串

  判断字符串的开头是否匹配正则表达式。

```
boolean lookingAt() 
```

##### ③匹配任意字符串

  判断字符串的任意部分是否匹配正则表达式。

```
boolean find() 
```

  设置字符串的开始索引，判断字符串的任意部分是否匹配正则表达式

```
boolean find(int start)
```

#### 3、获取匹配后字符串的详细信息

  返回上一个匹配的开始索引。

```
int start()   
```

  返回上一个匹配的结束索引。

```
int end() 
```

  返回上一个匹配的字符串。

```
String group() 
```

  例如：

```
public class Regular {
    public static void main(String[] args) {
        Pattern pattern = Pattern.compile("\\d+");
        Matcher matcher = pattern.matcher("我的微信是:123456 我的电话是:10086 我的网站是:zyxwmj.top，123aa");
        while (matcher.find()) {
            System.out.println(matcher.start());
            System.out.println(matcher.end());
            System.out.println(matcher.group());
        }
    }
}
```

#### 4、什么是捕获组

  捕获组可以通过从左到右计算其开括号来编号，编号是从 1 开始的。例如，在表达式 ((A)(B(C)))中，存在四个这样的组：

```
1        ((A)(B(C)))
2        (A)
3        (B(C))
4        (C)
```

#### 5、操作捕获组

  ①获取捕获组的个数。

```
int groupCount() 
```

  ②获取指定捕获组的开始索引。

```
int start(int group) 
```

  ③获取指定捕获组的结束索引。

```
int end(int group) 
```

  ④获取指定捕获组的字符串。

```
String group(int group) 
```

  ⑤例子：

```
Pattern pattern = Pattern.compile("(([0-9]+)([a-z]+))");
Matcher matcher = pattern.matcher("123aaa");
if (matcher.find()) {
	System.out.println("一共"+matcher.groupCount()+"个捕获组");
	for (int i = 1; i <= 3; i++) {
		System.out.println("第"+i+"个捕获组");
		System.out.println(matcher.start(i));
		System.out.println(matcher.end(i));
		System.out.println(matcher.group(i));
	}
}
```

#### 6、replaceXXX——替换字符串

  按匹配规则替换字符串。

```
String replaceAll(String replacement)   
```

  按指定规则替换字符串，只替换第一个。

```
String replaceFirst(String replacement)    
```

#### 7、reset——重置 Matcher 类

  重置所有匹配，回到最初。

```
Matcher reset()   
```

  重置所有匹配并重新设置字符串。

```
Matcher reset(CharSequence input)   
```

#### 8、appendXXX——追加字符串

  把 Matcher 中的字符串追加到 sb 后面。

```
StringBuffer appendTail(StringBuffer sb)  
```

  将字符串 replacement 与匹配的部分进行替换，并且把结果添加到一个 sb 结果集中，必须先匹配。

```
Matcher appendReplacement(StringBuffer sb, String replacement)
```

  例子：

```
public class Regular {
    public static void main(String[] args) {
        Pattern pattern = Pattern.compile("wmj");
        Matcher matcher = pattern.matcher("zyxwmj.top");
        StringBuffer sb = new StringBuffer();
        if (matcher.find()) {
            matcher.appendReplacement(sb, "zyx");
        }
        System.out.println(sb);
    }
}
```
