title: Nginx的安装、启动、关闭、卸载
date: '2019-09-14 21:32:25'
updated: '2019-09-15 10:48:14'
tags: [Nginx]
permalink: /articles/2019/09/14/1568467945137.html
---
![](https://img.hacpai.com/bing/20181211.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

###  1、在安装Nginx之前先安装nginx的依赖
```
yum -y install make zlib zlib-devel gcc-c++ libtool  openssl openssl-devel
```


### 2、安装 PCRE
```
# 下载 PCRE 安装包
wget http://downloads.sourceforge.net/project/pcre/pcre/8.35/pcre-8.35.tar.gz

# 解压安装包
tar zxvf pcre-8.35.tar.gz

# 进入安装包目录
cd pcre-8.35

# 安装  
./configure  
make && make install

# 查看版本
pcre-config --version

```
显示版本号表示安装成功
![image.png](https://img.hacpai.com/file/2019/09/image-9f940751.png)

### 3、 安装 Nginx
[下载Nginx的官网](https://nginx.org/en/download.html)
```
# 下载 Nginx安装包
wget http://nginx.org/download/nginx-1.6.2.tar.gz

# 解压安装包
tar zxvf nginx-1.6.2.tar.gz

#进入安装包目录
cd nginx-1.6.2

# 编译安装 （如果出错往下看）
./configure --prefix=/usr/local/nginx --with-http_stub_status_module --with-http_ssl_module --with-pcre=/usr/develop/pcre-8.35
make
make install

# 查看版本
/usr/local/nginx/sbin/nginx -v
```

  
### 注意：
--prefix 后的路径不能和Nginx的解压路径相同
报错信息
![W9FO01DBL0TGXQEBJJC.png](https://img.hacpai.com/file/2019/09/W9FO01DBL0TGXQEBJJC-670dcfed.png)

--with-pcre 后面跟 PCRE 的安装路径否则出错
报错信息
![EAKVEPRZPOHI2G6VX.png](https://img.hacpai.com/file/2019/09/EAKVEPRZPOHI2G6VX-fbab4c73.png)

显示版本号表示安装成功
![image.png](https://img.hacpai.com/file/2019/09/image-5459ceb4.png)


### 4、Nginx的启动  

nginx安装目录地址 -c nginx配置文件地址
```  
/usr/local/nginx/sbin/nginx -c /usr/local/nginx/conf/nginx.conf  
```
启动成功后直接通过域名或IP访问

![VPP0ZPVUGA66YR.png](https://img.hacpai.com/file/2019/09/VPP0ZPVUGA66YR-30292b23.png)

显示该页面表示启动成功！:smile:

### 5、Nginx的关闭
在Nginx的sbin目录下执行
```
# 快速关闭
./nginx -s stop

# 正常关闭
./nginx -s quit
```

### 6、Nginx的卸载
卸载前先关闭Nginx
```
# 首先查找关于Nginx的所有文件
sudo find / -name nginx*

# 删除Nginx的相关文件
sudo rm -rf file 文件路径
```
