title: Linux（Centos7.6）中Docker的介绍、安装、运行、挂载、卸载
date: '2019-09-15 17:38:32'
updated: '2019-09-21 18:55:00'
tags: [Docker, Linux]
permalink: /articles/2019/09/15/1568540312622.html
---
![](https://img.hacpai.com/bing/20180423.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 一、Docker 是什么？

  Docker 是一个虚拟环境容器，可以将你的开发环境、代码、配置文件等一并打包到这个容器中，并发布和应用到任意平台中。[Docker官网](https://docs.docker.com/)

### 二、Docker 的三个概念

#### 1. 镜像（Image）：

  类似于虚拟机中的镜像，是一个包含有文件系统的面向 Docker 引擎的只读模板。任何应用程序运行都需要环境，而镜像就是用来提供这种运行环境的。例如一个 Ubuntu 镜像就是一个包含 Ubuntu 操作系统环境的模板，同理在该镜像上装上 Apache 软件，就可以称为 Apache 镜像。

#### 2. 容器（Container）：

  类似于一个轻量级的沙盒，可以将其看作一个极简的 Linux 系统环境（包括 root 权限、进程空间、用户空间和网络空间等），以及运行在其中的应用程序。Docker 引擎利用容器来运行、隔离各个应用。容器是镜像创建的应用实例，可以创建、启动、停止、删除容器，各个容器之间是是相互隔离的，互不影响。注意：镜像本身是只读的，容器从镜像启动时，Docker 在镜像的上层创建一个可写层，镜像本身不变。

#### 3. 仓库（Repository）：

  类似于代码仓库，这里是镜像仓库，是 Docker 用来集中存放镜像文件的地方。注意与注册服务器（Registry）的区别：注册服务器是存放仓库的地方，一般会有多个仓库；而仓库是存放镜像的地方，一般每个仓库存放一类镜像，每个镜像利用 tag 进行区分，比如 Ubuntu 仓库存放有多个版本（12.04、14.04 等）的 Ubuntu 镜像。

### 三、Docker 的安装

[官方文档](https://docs.docker.com/install/linux/docker-ce/centos/)

#### 1）安装一些必要的系统工具
```
sudo yum install -y yum-utils device-mapper-persistent-data lvm2
```
#### 2）安装存储库 
&emsp;&emsp;使用阿里云的路径下载速度快
```
sudo yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
```
#### 3）更新 yum 缓存
```
sudo yum makecache fast
```
#### 4）安装 Docker-ce
```
sudo yum -y install docker-ce
```
#### 5）启动 Docker 进程
```
sudo systemctl start docker
```
#### 6）查看 Docker 的版本信息
```
docker version
```

版本信息
![image.png](https://img.hacpai.com/file/2019/09/image-21243315.png)
### 四、拉取并运行容器（以solo为例）
&emsp;&emsp;[搭建Solo官方教程](https://hacpai.com/article/1492881378588)
#### 1）拉取solo镜像
```
docker pull b3log/solo
```
#### 2）建立solo数据库
&emsp;&emsp;根据拉取镜像的要求建立数据库。.

#### 3）运行solo容器

```
docker run --detach --name solo --network=host \  
    --env RUNTIME_DB="MYSQL" \  
    --env JDBC_USERNAME="数据库账号" \  
    --env JDBC_PASSWORD="数据库密码" \  
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \  
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \ 
b3log/solo --listen_port=项目端口号 --server_scheme=http --server_host=访问域名或公网 IP
```

#### 4）查看所有的容器   
```   
docker ps -a   
```  
#### 5）查看当前启动的容器  
```  
docker ps  
```

#### 6）如果需要挂载皮肤
&emsp;&emsp;如果要使用其他皮肤，可以挂载目录 skins。
```
docker run --detach --name solo --network=host --volume 自己皮肤的目录:/opt/solo/skins/  \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="数据库账号" \
    --env JDBC_PASSWORD="数据库密码" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
b3log/solo --listen_port=项目端口号 --server_scheme=http --server_host=访问域名或公网 IP --server_port=
```
### 五、容器的关闭
#### 1）将容器退出
```
docker stop [NAME]/[CONTAINER ID]
```
#### 2）强制停止一个容器
```
docker kill [NAME]/[CONTAINER ID]
```

### 六、Docker 的的卸载

#### 1、旧版本

```
# 卸载旧版本  
sudo yum remove docker \  
 docker-client \  
 docker-client-latest \  
 docker-common \  
 docker-latest \  
 docker-latest-logrotate \  
 docker-logrotate \  
 docker-engine  
```

#### 2、新版本


##### 1）卸载Docker
```
sudo yum remove docker-ce
```
##### 2）删除其他数据
&emsp;&emsp;主机上的图像，容器，卷或自定义配置文件不会自动删除。要删除所有图像，容器和卷
```
sudo rm -rf /var/lib/docker
```

&emsp;&emsp;您必须手动删除任何已编辑的配置文件。

