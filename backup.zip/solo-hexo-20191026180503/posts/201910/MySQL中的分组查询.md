title: MySQL中的分组查询
date: '2019-10-08 15:52:56'
updated: '2019-10-10 17:08:42'
tags: [MySQL]
permalink: /articles/2019/10/08/1570521176176.html
---
![](https://img.hacpai.com/bing/20190819.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、作用
&emsp;&emsp;分组查询用于将数据库中的数据按指定列进行分组，使用 group  by 子句将表中的数据分为若干组。
### 二、语法
```
select 查询列表 
from表名 
[where 筛选条件] 
[group by 分组列表
[having 分组条件] ]
[order by 排序列表 [asc|desc] ] ;
```

### 三、例子
&emsp;&emsp;表名为 student
#### 1、表结构

|名|类型|长度|键|
|:---:|:---:|:---:|:---:|
|id|int|11|主键|
|name|varchar|255|无|
|age|int|255|无|
|class|varchar|11|无|

#### 2、数据表

|id|name|age|class|
|:---:|:---:|:---:|:---:|
|1|小张|10|一班|
|2|小王|12|二班|
|3|小姣|18|二班|
|4|小兴|15|一班|
|5|小易|7|一班|
|6|小梦|20|二班|

#### 3、实例
##### 1）统计每个班级的人数

```
select class,count(*) as 人数 
from student
group by class;
```

&emsp;&emsp;运行结果：

|class|人数|
|:---:|:---:|
|一班|3|
|二班|3|

##### 2）分组显示每个班级的所有学生信息
&emsp;&emsp;group by 和 group_concat 函数结合使用。

```
select group_concat(id) id,group_concat(name) name,class 
from student
group by class;
```
&emsp;&emsp;运行结果：

|id|name|class|
|:---:|:---:|:---:|
|1,4,5	|小张,小兴,小易	|一班|
|2,3,6	|小王,小姣,小梦|	二班|

##### 3）获取每个班中年龄大于 12 的学生

```
select group_concat(id) id,group_concat(name) name,class 
from student
where age>12
group by class
```

&emsp;&emsp;运行结果：

|id|name|class|
|:---:|:---:|:---:|
|4	|小兴	|一班|
|3,6	|小姣,小梦	|二班|

##### 4）显示平均年龄大于 15 的班级

```
select class   
from student
group by class  
having avg(age)>15
```

&emsp;&emsp;运行结果：

|class|
|:---:|
|二班|

### 四、筛选条件的分类
&emsp;&emsp;分组查询中的筛选条件分为两类

||数据源|位置|关键字|
|:---:|:---:|:---:|:---:|
|分组前筛选|原始表|在 group by 前|where|
|分组后筛选|分组后的结果集|在 group by 后|having|

