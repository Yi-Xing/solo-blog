title: Linux（Centos7.6）中下载MySQL
date: '2019-09-20 08:51:58'
updated: '2019-09-20 21:53:44'
tags: [MySQL, Linux]
permalink: /articles/2019/09/20/1568940718608.html
---
![](https://img.hacpai.com/bing/20190530.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 1.MySQL的下载
[下载MySQL的Yum存储库官网](https://dev.mysql.com/downloads/repo/yum/)

#### 1）下载MySQL的Yum存储库
```
wget https://dev.mysql.com/get/mysql80-community-release-el7-3.noarch.rpm
```
#### 2）安装mysql源
```
yum -y localinstall mysql80-community-release-el7-3.noarch.rpm
```
#### 3）安装 MySQL 服务器端
```
yum -y install mysql-community-server
```
#### 4）启动 MySQL 服务
```
service mysqld start
```
#### 5）查看MySQL的运行状态  
```
systemctl status mysqld
```
显示以下信息表示运行成功
![image.png](https://img.hacpai.com/file/2019/09/image-b1aa9c0b.png)

### 2、修改密码

#### 1）查看默认密码
```
grep "password" /var/log/mysqld.log
```
#### 2）进入MySQL命令框（按回车后输入密码）
```
mysql -uroot -p
```
#### 3）修改密码策略（不设置可能造成修改密码失败）
**旧版本**
```~~~~
set global validate_password_policy=0;
set global validate_password_length=1;
```
**新版本**
```
set global validate_password.policy=0;
set global validate_password.length=1;
```
#### 4）修改密码
```
ALTER USER 'root'@'localhost' IDENTIFIED BY '新密码';
```
#### 5）退出MySQL的命令框  
```
exit
```
### 3、外网访问

#### 1）进入MySQL命令框（按回车后输入密码）
```
mysql -uroot -p
```
#### 2）设置访问权限
① 将host设置为%表示任何ip都能连接mysql
```
update user set host='%' where user='root' and host='localhost';
```
② 当然也可以将host指定为某个ip
```
update user set host='170.0.0.1' where user='root' and host='localhost';  
```
#### 3）刷新权限表,使配置生效
```
flush privileges;
```
&emsp;&emsp;接着开启服务器防火墙是否开放了3306端口（如果是阿里云服务器还需要在控制台中开放端口），接下来就可以远程连接了。
